<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

            <nav class="navbar navbar-expand-lg navbar-custom">

                <div class="container-fluid">

                    <span class="navbar-brand mb-0 h1">Company Details</span>

                </div>

            </nav>



            <div class="main-content p-4">

                <div class="card bg-white p-3 border-0">

                    <div class="card-body">

                        <h4><?php echo e($company->name); ?></h4>

                        <p><strong>Country:</strong> <?php echo e($company->country ?? 'N/A'); ?></p>

                        <p><strong>Timezone:</strong> <?php echo e($company->timezone); ?></p>

                        <p><strong>Plan:</strong> <?php echo e($company->plan ? $company->plan->name : 'None'); ?></p>

                        <p><strong>Users:</strong> <?php echo e($company->users->count()); ?></p>

                        <p><strong>Machines:</strong> <?php echo e($company->machines->count()); ?></p>



                        <a href="<?php echo e(route('admin.companies.edit', $company)); ?>" class="btn btn-warning">Edit</a>

                        <a href="<?php echo e(route('admin.companies.index')); ?>" class="btn btn-secondary">Back</a>

                    </div>

                </div>

            </div>

        </div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/resources/views/admin/companies/show.blade.php ENDPATH**/ ?>