<?php
$page_title = "Detail View";
?>

<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-content p-3 bg-white">
  <div class="card-header d-flex justify-content-between align-items-center mb-3">
    <h4 class="header-title mb-0">Detail View</h4>
    <a href="<?php echo e(route('user.machines.index')); ?>" class="btn btn-secondary">← Back to List</a>
  </div>

  <div class="card-body">
    <?php if(session('success')): ?>
      <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <h5>Name: <?php echo e($machine->name); ?></h5>
    <p><strong>Type:</strong> <?php echo e($machine->machine_type); ?></p>
    <p><strong>Serial Number:</strong> <?php echo e($machine->serial_number); ?></p>
    <p><strong>Location:</strong> <?php echo e($machine->location); ?></p>
    <p><strong>Status:</strong> <?php echo e($machine->status); ?></p>
    <p><strong>Installed At:</strong> <?php echo e(optional($machine->installed_at)->format('Y-m-d')); ?></p>
  </div>
</div>
<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/predictormt/public_html/UAT/resources/views/user/machines/view.blade.php ENDPATH**/ ?>