<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">
                          Add Prediction
                        </span>

                        <div class="navbar-nav ms-auto ">
      <a href="<?php echo e(route('admin.predictions.index')); ?>" class="btn themeBtn">Back</a>


                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">



  <?php if($errors->any()): ?>

    <div class="alert alert-danger">

      <ul class="mb-0">

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>

  <?php endif; ?>



  <form method="POST" action="<?php echo e(route('admin.predictions.store')); ?>" class="bg-white p-3 border-0 rounded">

    <?php echo csrf_field(); ?>

    <div class="row g-3">

      <div class="col-md-6">

        <label class="form-label">Machine</label>

        <select name="machine_id" class="form-select" required>

          <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($machine->id); ?>"><?php echo e($machine->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Sensor (optional)</label>

        <select name="sensor_id" class="form-select">

          <option value="">None</option>

          <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($sensor->id); ?>"><?php echo e($sensor->device_id); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Predicted At</label>

        <input type="datetime-local" name="predicted_at" class="form-control" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Predicted Failure At</label>

        <input type="datetime-local" name="predicted_failure_at" class="form-control">

      </div>

      <div class="col-md-6">

        <label class="form-label">Probability (0-1)</label>

        <input type="number" step="0.0001" min="0" max="1" name="probability" class="form-control">

      </div>

      <div class="col-md-6">

        <label class="form-label">Component</label>

        <input type="text" name="component" class="form-control">

      </div>

      <div class="col-md-6">

        <label class="form-label">Model Version</label>

        <input type="text" name="model_version" class="form-control" required>

      </div>

      <div class="col-12">

        <label class="form-label">Explanation (JSON)</label>

        <textarea name="explanation" class="form-control" rows="4" placeholder='{"importance": {"vibration": 0.8}}'></textarea>

      </div>

      <div class="col-md-6">

        <label class="form-label">Status</label>

        <select name="status" class="form-select" required>

          <?php $__currentLoopData = ['open','acknowledged','converted','resolved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

    </div>

    <div class="mt-3">

      <button type="submit" class="btn btn-primary">Create</button>

    </div>

  </form>

</div>

</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/resources/views/admin/predictions/create.blade.php ENDPATH**/ ?>