<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

            <nav class="navbar navbar-expand-lg navbar-custom">

                <div class="container-fluid">

                    <span class="navbar-brand mb-0 h1">Plan Details</span>

                </div>

            </nav>



            <div class="main-content p-4">

                <div class="card bg-white p-3 border-0">

                    <div class="card-body">

                        <h4><?php echo e($plan->name); ?></h4>

                        <p><strong>Price:</strong> $<?php echo e(number_format($plan->price,2)); ?> <span class="text-muted"><?php echo e($plan->billing_interval ? ' - ' . $plan->billing_interval : ''); ?></span></p>

                        <?php if($plan->description): ?>

                            <p><?php echo e($plan->description); ?></p>

                        <?php endif; ?>

                        <p><strong>Machines Included:</strong> <?php echo e($plan->machines_included); ?></p>

                        <p><strong>Companies on this plan:</strong> <?php echo e($plan->companies->count()); ?></p>



                        <?php if(!empty($plan->features)): ?>

                            <h5 class="mt-3">Features</h5>

                            <ul>

                                <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><?php echo e($feature); ?></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>

                        <?php endif; ?>



                        <a href="<?php echo e(route('admin.plans.edit', $plan)); ?>" class="btn btn-warning">Edit</a>

                        <a href="<?php echo e(route('admin.plans.index')); ?>" class="btn btn-secondary">Back</a>

                    </div>

                </div>

            </div>

    </div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/plans/show.blade.php ENDPATH**/ ?>