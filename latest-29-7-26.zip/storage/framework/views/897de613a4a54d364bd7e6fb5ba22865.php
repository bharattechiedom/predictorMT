<?php
$page_title = "Sensors";
?>

<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <div class="wrapper active">
    <div class="page-content">
      <div class="page-container p-3">
        <div class="meetingPpage">
          <!-- 🔹 Header -->
          <div class="card-header d-flex flex-wrap align-items-center gap-2 mb-4">
            <div class="flex-grow-1">
              <h4 class="header-title mb-0">Sensors Overview</h4>
              <nav aria-label="breadcrumb" class="mt-2">
                <ol class="breadcrumb p-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Sensors</li>
                </ol>
              </nav>
            </div>

            <div class="d-flex gap-2">
              <div class="search-box position-relative w-auto">
                <input type="text" class="form-control pe-5" id="sensorSearch" placeholder="Search Sensors...">
                <span class="position-absolute top-50 end-0 translate-middle-y pe-3" style="color: #ccc;">
                  <i class="bi bi-search"></i>
                </span>
              </div>
              <a href="<?php echo e(route('user.sensors.create')); ?>" class="btn btn-dark">Add Sensor +</a>
            </div>
          </div>

          <?php if(session('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('success')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>

          <!-- 🔹 Content Section -->
          <div class="row g-3">
            <!-- Sensors Summary -->
            <div class="col-12">
              <div class="card foodcard p-3">
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th>Device ID</th>
                        <th>Machine</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Battery</th>
                        <th>Last Seen</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($sensor->device_id); ?></td>
                        <td><?php echo e($sensor->machine->name); ?></td>
                        <td><?php echo e($sensor->sensor_type); ?></td>
                        <td>
                          <?php
                            $statusClass = [
                                'active' => 'success',
                                'inactive' => 'warning',
                                'faulty' => 'danger',
                                'provisioning' => 'info'
                            ][$sensor->status] ?? 'secondary';
                          ?>
                          <span class="badge bg-<?php echo e($statusClass); ?>"><?php echo e($sensor->status); ?></span>
                        </td>
                        <td>
                          <?php if($sensor->battery_level !== null): ?>
                          <div class="progress" style="height: 20px;">
                            <div class="progress-bar bg-<?php echo e($sensor->battery_level > 20 ? 'success' : 'danger'); ?>" 
                                 role="progressbar" 
                                 style="width: <?php echo e($sensor->battery_level); ?>%">
                              <?php echo e($sensor->battery_level); ?>%
                            </div>
                          </div>
                          <?php else: ?>
                          N/A
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($sensor->last_seen ? $sensor->last_seen->diffForHumans() : 'Never'); ?></td>
                        <td>
                          <div class="d-flex gap-2">
                            <a href="<?php echo e(route('user.sensors.edit', $sensor)); ?>" class="btn btn-sm btn-outline-info">
                              <i class="bi bi-pencil"></i>
                            </a>
                            <a href="<?php echo e(route('user.sensors.show', $sensor)); ?>" class="btn btn-sm btn-outline-info">
                              <i class="bi bi-eye"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('user.sensors.destroy', $sensor)); ?>" 
                                  onsubmit="return confirm('Are you sure you want to delete this sensor?');" 
                                  style="display: inline;">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              <button type="submit" class="btn btn-sm btn-outline-info  ">
                                <i class="bi bi-trash"></i>
                              </button>
                            </form>
                          </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr>
                        <td colspan="7" class="text-center">No sensors found</td>
                      </tr>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
                <div class="mt-3">
                  <?php echo e($sensors->links()); ?>

                </div>
              </div>
            </div>
          </div> <!-- /row -->
        </div> <!-- /meetingPpage -->
      </div> <!-- /page-container -->
    </div> <!-- /page-content -->
  </div> <!-- /wrapper -->

<script>
(function() {
    'use strict';
    
    const searchInput = document.getElementById('sensorSearch');
    const table = document.querySelector('.table tbody');
    
    if (searchInput && table) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            const rows = table.querySelectorAll('tr');
            
            rows.forEach(function(row) {
                if (row.querySelector('td[colspan]')) {
                    return;
                }
                
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
})();
</script>
 
</body>

<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/predictormt/public_html/UAT/resources/views/user/sensors/index.blade.php ENDPATH**/ ?>