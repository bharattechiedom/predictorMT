<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="text-align:center;padding:80px 20px;">
    <h1>Successfully Unsubscribed 😔</h1>
    <p>You will no longer receive our emails.</p>
    <a href="<?php echo e(url('/')); ?>" style="color:#0d6efd;">Go Back to Website</a>
</div>
<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/resources/views/unsubscribed.blade.php ENDPATH**/ ?>