<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">
      <div class="container-fluid">
          <span class="navbar-brand mb-0 h1 text-white">
            Invoices
          </span>
          <div class="navbar-nav ms-auto ">
              <a href="<?php echo e(route('admin.invoices.create')); ?>" class="btn themeBtn">Add Invoice</a>
          </div>
      </div>
  </nav>
<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">




  <?php if(session('success')): ?>

    <div class="alert alert-success"><?php echo e(session('success')); ?></div>

  <?php endif; ?>



  <div class="table-responsive bg-white p-2">

    <table class="table table-hover table-bordered">

      <thead class="bg-light">

        <tr>

          <th>#</th>

          <th>Company</th>

          <th>Amount</th>

          <th>Period</th>

          <th>Status</th>

          <th>Actions</th>

        </tr>

      </thead>

      <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

          <td><?php echo e($invoice->id); ?></td>

          <td><?php echo e(optional($invoice->company)->name); ?></td>

          <td><?php echo e($invoice->amount); ?></td>

          <td><?php echo e(optional($invoice->billing_period_start)->format('Y-m-d')); ?> → <?php echo e(optional($invoice->billing_period_end)->format('Y-m-d')); ?></td>

          <td><?php echo e($invoice->status); ?></td>

          <td class="d-flex gap-2">

            <a class="btn btn-sm btn-outline-primary btn-action" href="<?php echo e(route('admin.invoices.show', $invoice)); ?>"><i class="fas fa-eye"></i></a>

            <a class="btn btn-sm btn-outline-warning btn-action" href="<?php echo e(route('admin.invoices.edit', $invoice)); ?>"><i class="fas fa-edit"></i></a>

            <form action="<?php echo e(route('admin.invoices.destroy', $invoice)); ?>" method="POST" onsubmit="return confirm('Delete this invoice?');">

              <?php echo csrf_field(); ?>

              <?php echo method_field('DELETE'); ?>

              <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>

            </form>

          </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr><td colspan="6" class="text-center">No invoices found.</td></tr>

        <?php endif; ?>

      </tbody>

    </table>

  </div>



  <div class="mt-3">

    <?php echo e($invoices->links()); ?>


  </div>

</div>
</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/resources/views/admin/invoices/index.blade.php ENDPATH**/ ?>