<?php

$page_title = "Sensor Details";

?>

<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="wrapper active">

    <div class="page-content">

        <div class="page-container p-3">


                <!-- Sensor Info -->
 <div class="card">

                <div class="card-header d-flex justify-content-between align-items-center py-2">

                    <h4 class="mb-0 text-white">Sensor Details</h4>
                          <a href="<?php echo e(route('user.sensors.index')); ?>" class="btn btn-secondary">Back</a>

                </div>

                <div class="card-body bg-white">


 


  <?php if(session('success')): ?>

    <div class="alert alert-success"><?php echo e(session('success')); ?></div>

  <?php endif; ?>



  <div class="bg-white p-3">

    <dl class="row mb-0">

      <dt class="col-sm-3">ID</dt><dd class="col-sm-9"><?php echo e($sensor->id); ?></dd>

      <dt class="col-sm-3">Device ID</dt><dd class="col-sm-9"><?php echo e($sensor->device_id); ?></dd>

      <dt class="col-sm-3">Type</dt><dd class="col-sm-9"><?php echo e($sensor->sensor_type); ?></dd>

      <dt class="col-sm-3">Machine</dt><dd class="col-sm-9"><?php echo e(optional($sensor->machine)->name); ?></dd>

      <dt class="col-sm-3">Firmware</dt><dd class="col-sm-9"><?php echo e($sensor->firmware_version); ?></dd>

      <dt class="col-sm-3">Battery</dt><dd class="col-sm-9"><?php echo e($sensor->battery_level); ?>%</dd>

      <dt class="col-sm-3">Last Seen</dt><dd class="col-sm-9"><?php echo e(optional($sensor->last_seen)->format('Y-m-d H:i')); ?></dd>

      <dt class="col-sm-3">Status</dt><dd class="col-sm-9"><?php echo e($sensor->status); ?></dd>

      <dt class="col-sm-3">Created</dt><dd class="col-sm-9"><?php echo e(optional($sensor->created_at)->toDayDateTimeString()); ?></dd>

      <dt class="col-sm-3">Updated</dt><dd class="col-sm-9"><?php echo e(optional($sensor->updated_at)->toDayDateTimeString()); ?></dd>

    </dl>

  </div>

</div>



                <!-- Recent Readings -->

                



                

            </div>

        </div>

    </div>

</div>





<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/predictormt/public_html/resources/views/user/sensors/show.blade.php ENDPATH**/ ?>