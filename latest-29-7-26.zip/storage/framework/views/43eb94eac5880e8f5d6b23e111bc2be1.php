<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

            <nav class="navbar navbar-expand-lg navbar-custom">

                <div class="container-fluid">

                    <span class="navbar-brand mb-0 h1">Add Plan</span>

                </div>

            </nav>



            <div class="main-content p-4">

                    <div class="card bg-white p-3 border-0">

                    <div class="card-body">



                        <?php if($errors->any()): ?>

                            <div class="alert alert-danger">

                                <ul class="mb-0">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>

                            </div>

                        <?php endif; ?>



                        <form action="<?php echo e(route('admin.plans.store')); ?>" method="POST">

                            <?php echo csrf_field(); ?>



                            <div class="mb-3">

                                <label class="form-label">Name</label>

                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Price</label>

                                <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', '0.00')); ?>" required>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Machines Included</label>

                                <input type="number" name="machines_included" class="form-control" value="<?php echo e(old('machines_included', 1)); ?>" required>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Billing Interval (label)</label>

                                <input type="text" name="billing_interval" class="form-control" value="<?php echo e(old('billing_interval')); ?>" placeholder="e.g. per machine / month">

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Short Description</label>

                                <textarea name="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Features (one per line)</label>

                                <textarea name="features_text" class="form-control" rows="6" placeholder="30h Fast generations\nUnlimited Relaxed generations\nGeneral commercial terms\nAccess to member dashboard\nOptional credit top ups\nSetup fees, sensor costs, and dashboard access"><?php echo e(old('features_text')); ?></textarea>

                            </div>



                            <div class="mt-3">

                                <button class="btn btn-primary">Create Plan</button>

                                <a href="<?php echo e(route('admin.plans.index')); ?>" class="btn btn-secondary">Cancel</a>

                            </div>

                        </form>

                    </div>

                </div>



        <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/plans/create.blade.php ENDPATH**/ ?>