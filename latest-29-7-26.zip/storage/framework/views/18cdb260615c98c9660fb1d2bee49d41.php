<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

            <nav class="navbar navbar-expand-lg navbar-custom">

                <div class="container-fluid">

                    <span class="navbar-brand mb-0 h1">User Details</span>

                </div>

            </nav>



            <div class="main-content p-4">

                <div class="card bg-white p-3 border-0">

                    <div class="card-body">

                        <h4><?php echo e($user->name); ?></h4>

                        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>

                        <p><strong>Role:</strong> <?php echo e(ucfirst($user->role)); ?></p>

                        <p><strong>Company:</strong> <?php echo e($user->company ? $user->company->name : 'None'); ?></p>

                        <p><strong>Phone:</strong> <?php echo e($user->phone ?? 'N/A'); ?></p>



                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-warning">Edit</a>

                        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">Back</a>

                    </div>

                </div>

            </div>

    </div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/users/show.blade.php ENDPATH**/ ?>