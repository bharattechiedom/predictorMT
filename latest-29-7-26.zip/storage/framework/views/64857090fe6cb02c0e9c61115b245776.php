<?php if(!auth()->check()): ?>
<footer>

   <div class="container">

  <div class="row">

    <!-- 1️⃣ Column 1: Logo & Address -->

    <div class="col-md-3 col-sm-6">

      <div class="footer-new-contact">

        <div class="footer-logo">

          <img itemprop="logo" class="lazy1" src="<?php echo e(asset('public/assets/user/images/footer-logo.png')); ?>"

            data-src="imgpredictor/PREDICTORMT TECH SOLUTIONS INC white logo.png" alt="Predictor MT">

        </div>

        <div class="footer-social-icon">

          <ul>

            <li itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">

              <i class="fa fa-map-marker" aria-hidden="true"></i>

              <p><span>PREDICTOTMT TECH SOLUTIONS INC. 304 – 8920 Woodbine Avenue Markham, ON, L3R 9W9</span></p>

            </li>

            <li itemprop="email">

              <i class="fa fa-envelope-o" aria-hidden="true"></i>

              <a href="mailto:ceo@predictormt.ca">ceo@predictormt.ca</a>

            </li>

          </ul>

        </div>

      </div>

    </div>



    <!-- 2️⃣ Column 2: Social + Rating -->

    <div class="col-md-3 col-sm-6">

      <div class="client-rating" style="color: #fff; font-size: 14px;">

        <div class="footer-icons">

          <p>Follow, like, tweet or post. We would love to interact with you</p>

          <ul>

            <li><a href="javascript:avoid();"><img class="lazy1" src="<?php echo e(asset('public/assets/user/images/fb-icon.png')); ?>" alt="fb-icon"></a></li>

            <li><a href="javascript:avoid();"><img class="lazy1" src="<?php echo e(asset('public/assets/user/images/ln-icon.png')); ?>" alt="ln-icon"></a></li>

            <li><a href="javascript:avoid();"><img class="lazy1" src="<?php echo e(asset('public/assets/user/images/twitter-icon.png')); ?>" alt="twitter-icon"></a></li>

            <li><a href="javascript:avoid();"><img class="lazy1" src="<?php echo e(asset('public/assets/user/images/insta-icon.png')); ?>" alt="insta-icon"></a></li>

          </ul>

        </div>

        <p>We're happy to share our rating!</p>

        <div class="client-rating-box">

          <span>Client Rating</span>

          <p><img src="<?php echo e(asset('public/assets/user/images/footer-star-img.png')); ?>"></p>

        </div>

        <div itemprop="aggregateRating" itemscope itemtype="#">

          Rated <span itemprop="ratingValue">4.9</span>/5 based on <span itemprop="reviewCount">49</span> reviews across the world.

        </div>

      </div>

    </div>



    <!-- 3️⃣ Column 3: Quick Links -->

    <div class="col-md-3 col-sm-6">

      <div class="footer-links">

        <h5>Quick Links</h5>

        <ul>

          <li><a href="index.php">Home</a></li>

          <li><a href="about.php">About Us</a></li>

          <li><a href="services.php">Services</a></li>

          <li><a href="team.php">Our Team</a></li>

          <li><a href="pricing.php">Subscription</a></li>

          <li><a href="contactus.php">Contact Us</a></li>

        </ul>

      </div>

    </div>



    <!-- 4️⃣ Column 4: Newsletter -->

    <div class="col-md-3 col-sm-6">

      <div class="footer-newsletter">

        <h6>Subscribe To Get Email Updates !</h6>

        <div class="form-group mc-field-group">

          <input type="email" name="EMAIL" placeholder="Enter Email Address...." id="mce-EMAIL"

            class="required email LoNotSensitive">

          <button type="button" value="Subscribe" name="subscribe" class="button">Submit</button>

        </div>

        <div id="mce-responses" class="clear">

          <div class="response" id="mce-error-response" style="display:none"></div>

          <div class="response" id="mce-success-response" style="display:none"></div>

        </div>

        <div style="position: absolute; left: -5000px;" aria-hidden="true">

          <input type="text" name="b_58086a97c98c25701f7866e06_54810532d8" tabindex="-1" value="">

        </div>

      </div>

    </div>

  </div>

</div>



<div class="footer-bottom">

  <div class="container">

    <div class="row">

      <div class="col-md-6 col-sm-5">

        <p><i class="fa fa-copyright" aria-hidden="true"></i> 2024. All Rights Reserved <span itemprop="name">Predictor MT</span> Inc.</p>

      </div>

      <div class="col-md-4 col-sm-5 pull-right">

        <ul>

          <li><a href="ourpolicy.php">Privacy Policy</a></li>

          <li><a href="termcondition.php">Terms &amp; Conditions</a></li>

        </ul>

      </div>

    </div>

  </div>

</div>



  </footer>

</div>

     <!-- end Footer -->



     </div>



     <!-- ============================================================== -->

     <!-- End Page content -->

     <!-- ============================================================== -->



     </div>

     <!-- END wrapper -->



     <!-- Theme Settings -->

     <div class="offcanvas offcanvas-end" tabindex="-1" id="theme-settings-offcanvas">

         <div class="d-flex align-items-center gap-2 px-3 py-3 offcanvas-header border-bottom border-dashed">

             <h5 class="flex-grow-1 mb-0">Theme Settings</h5>



             <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

         </div>



         <div class="offcanvas-body p-0 h-100 simplebar-scrollable-y" data-simplebar="init">

             <div class="simplebar-wrapper" style="margin: 0px;">

                 <div class="simplebar-height-auto-observer-wrapper">

                     <div class="simplebar-height-auto-observer"></div>

                 </div>

                 <div class="simplebar-mask">

                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">

                         <div class="simplebar-content-wrapper" tabindex="0" role="region"

                             aria-label="scrollable content" style="height: 100%; overflow: hidden scroll;">

                             <div class="simplebar-content" style="padding: 0px;">

                                 <div class="p-3 border-bottom border-dashed">

                                     <h5 class="mb-3 fs-16 fw-bold">Color Scheme</h5>



                                     <div class="row">

                                         <div class="col-4">

                                             <div class="form-check card-radio">

                                                 <input class="form-check-input" type="radio" name="data-bs-theme"

                                                     id="layout-color-light" value="light">

                                                 <label

                                                     class="form-check-label p-3 w-100 d-flex justify-content-center align-items-center"

                                                     for="layout-color-light">

                                                     <iconify-icon icon="solar:sun-bold-duotone"

                                                         class="fs-32 text-muted"><template shadowrootmode="open">

                                                             <style data-style="data-style">

                                                             :host {

                                                                 display: inline-block;

                                                                 vertical-align: 0

                                                             }



                                                             span,

                                                             svg {

                                                                 display: block

                                                             }

                                                             </style><svg xmlns="http://www.w3.org/2000/svg" width="1em"

                                                                 height="1em" viewBox="0 0 24 24">

                                                                 <path fill="currentColor"

                                                                     d="M18 12a6 6 0 1 1-12 0a6 6 0 0 1 12 0"></path>

                                                                 <path fill="currentColor" fill-rule="evenodd"

                                                                     d="M12 1.25a.75.75 0 0 1 .75.75v1a.75.75 0 0 1-1.5 0V2a.75.75 0 0 1 .75-.75M1.25 12a.75.75 0 0 1 .75-.75h1a.75.75 0 0 1 0 1.5H2a.75.75 0 0 1-.75-.75m19 0a.75.75 0 0 1 .75-.75h1a.75.75 0 0 1 0 1.5h-1a.75.75 0 0 1-.75-.75M12 20.25a.75.75 0 0 1 .75.75v1a.75.75 0 0 1-1.5 0v-1a.75.75 0 0 1 .75-.75"

                                                                     clip-rule="evenodd"></path>

                                                                 <path fill="currentColor"

                                                                     d="M4.398 4.398a.75.75 0 0 1 1.061 0l.393.393a.75.75 0 0 1-1.06 1.06l-.394-.392a.75.75 0 0 1 0-1.06m15.202 0a.75.75 0 0 1 0 1.06l-.392.393a.75.75 0 0 1-1.06-1.06l.392-.393a.75.75 0 0 1 1.06 0m-1.453 13.748a.75.75 0 0 1 1.061 0l.393.393a.75.75 0 0 1-1.06 1.06l-.394-.392a.75.75 0 0 1 0-1.06m-12.295 0a.75.75 0 0 1 0 1.06l-.393.393a.75.75 0 1 1-1.06-1.06l.392-.393a.75.75 0 0 1 1.06 0"

                                                                     opacity=".5"></path>

                                                             </svg>

                                                         </template></iconify-icon>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Light</h5>

                                         </div>



                                         <div class="col-4">

                                             <div class="form-check card-radio">

                                                 <input class="form-check-input" type="radio" name="data-bs-theme"

                                                     id="layout-color-dark" value="dark">

                                                 <label

                                                     class="form-check-label p-3 w-100 d-flex justify-content-center align-items-center"

                                                     for="layout-color-dark">

                                                     <iconify-icon icon="solar:cloud-sun-2-bold-duotone"

                                                         class="fs-32 text-muted"><template shadowrootmode="open">

                                                             <style data-style="data-style">

                                                             :host {

                                                                 display: inline-block;

                                                                 vertical-align: 0

                                                             }



                                                             span,

                                                             svg {

                                                                 display: block

                                                             }

                                                             </style><svg xmlns="http://www.w3.org/2000/svg" width="1em"

                                                                 height="1em" viewBox="0 0 24 24">

                                                                 <path fill="currentColor"

                                                                     d="M11.5 8a3.5 3.5 0 1 1-7 0a3.5 3.5 0 0 1 7 0"

                                                                     opacity=".5"></path>

                                                                 <path fill="currentColor" fill-rule="evenodd"

                                                                     d="M7.5 1.25a.75.75 0 0 1 .75.75v.5a.75.75 0 0 1-1.5 0V2a.75.75 0 0 1 .75-.75M3.08 3.08a.75.75 0 0 1 1.062 0l.216.217a.75.75 0 0 1-1.061 1.06l-.216-.216a.75.75 0 0 1 0-1.06m8.839 0a.75.75 0 0 1 0 1.061l-.216.216a.75.75 0 1 1-1.06-1.06l.215-.216a.75.75 0 0 1 1.061 0M1.25 7.5A.75.75 0 0 1 2 6.75h.5a.75.75 0 0 1 0 1.5H2a.75.75 0 0 1-.75-.75m3.108 3.143a.75.75 0 0 1 0 1.06l-.216.216a.75.75 0 0 1-1.061-1.06l.216-.216a.75.75 0 0 1 1.06 0"

                                                                     clip-rule="evenodd" opacity=".5"></path>

                                                                 <path fill="currentColor"

                                                                     d="M16.286 22C19.442 22 22 19.472 22 16.353c0-2.472-1.607-4.573-3.845-5.338C17.837 8.194 15.415 6 12.476 6C9.32 6 6.762 8.528 6.762 11.647c0 .69.125 1.35.354 1.962a4.4 4.4 0 0 0-.83-.08C3.919 13.53 2 15.426 2 17.765S3.919 22 6.286 22z">

                                                                 </path>

                                                             </svg>

                                                         </template></iconify-icon>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Dark</h5>

                                         </div>

                                     </div>

                                 </div>



                                 <div class="p-3 border-bottom border-dashed">

                                     <h5 class="mb-3 fs-16 fw-bold">Topbar Color</h5>



                                     <div class="row">

                                         <div class="col-3 darkMode">

                                             <div class="form-check card-radio">

                                                 <input class="form-check-input" type="radio" name="data-topbar-color"

                                                     id="topbar-color-light" value="light">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="topbar-color-light">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span

                                                             class="p-2 d-inline-flex shadow rounded-circle bg-white"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Light</h5>

                                         </div>



                                         <div class="col-3">

                                             <div class="form-check card-radio">

                                                 <input class="form-check-input" type="radio" name="data-topbar-color"

                                                     id="topbar-color-dark" value="dark">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="topbar-color-dark">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span class="p-2 d-inline-flex shadow rounded-circle"

                                                             style="background-color: #313a46;"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Dark</h5>

                                         </div>



                                         <div class="col-3">

                                             <div class="form-check card-radio">

                                                 <input class="form-check-input" type="radio" name="data-topbar-color"

                                                     id="topbar-color-brand" value="brand">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="topbar-color-brand">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span

                                                             class="p-2 d-inline-flex shadow rounded-circle bg-primary"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Brand</h5>

                                         </div>



                                         <div class="col-3">

                                             <div class="form-check card-radio">

                                                 <input class="form-check-input" type="radio" name="data-topbar-color"

                                                     id="topbar-color-gradient" value="gradient">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="topbar-color-gradient">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span class="p-2 d-inline-flex shadow rounded-circle"

                                                             style="background: linear-gradient(to top,#5d6dc3,#3c86d8);"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Gradient</h5>

                                         </div>

                                     </div>

                                 </div>



                                 <div class="p-3 border-bottom border-dashed">

                                     <h5 class="mb-3 fs-16 fw-bold">Menu Color</h5>



                                     <div class="row">

                                         <div class="col-3 darkMode">

                                             <div class="form-check sidebar-setting card-radio">

                                                 <input class="form-check-input" type="radio" name="data-menu-color"

                                                     id="sidenav-color-light" value="light">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="sidenav-color-light">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span

                                                             class="p-2 d-inline-flex shadow rounded-circle bg-white"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Light</h5>

                                         </div>



                                         <div class="col-3">

                                             <div class="form-check sidebar-setting card-radio">

                                                 <input class="form-check-input" type="radio" name="data-menu-color"

                                                     id="sidenav-color-dark" value="dark">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="sidenav-color-dark">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span class="p-2 d-inline-flex shadow rounded-circle"

                                                             style="background-color: #313a46;"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Dark</h5>

                                         </div>

                                         <div class="col-3">

                                             <div class="form-check sidebar-setting card-radio">

                                                 <input class="form-check-input" type="radio" name="data-menu-color"

                                                     id="sidenav-color-brand" value="brand">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="sidenav-color-brand">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span

                                                             class="p-2 d-inline-flex shadow rounded-circle bg-primary"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Brand</h5>

                                         </div>

                                         <div class="col-3">

                                             <div class="form-check sidebar-setting card-radio">

                                                 <input class="form-check-input" type="radio" name="data-menu-color"

                                                     id="sidenav-color-gradient" value="gradient">

                                                 <label class="form-check-label p-0 avatar-lg w-100 bg-light"

                                                     for="sidenav-color-gradient">

                                                     <span

                                                         class="d-flex align-items-center justify-content-center h-100">

                                                         <span class="p-2 d-inline-flex shadow rounded-circle"

                                                             style="background: linear-gradient(to top,#5d6dc3,#3c86d8);"></span>

                                                     </span>

                                                 </label>

                                             </div>

                                             <h5 class="fs-14 text-center text-muted mt-2">Gradient</h5>

                                         </div>

                                     </div>

                                 </div>





                                 <div class="p-3 border-bottom border-dashed d-none">

                                     <div class="d-flex justify-content-between align-items-center">

                                         <h5 class="fs-16 fw-bold mb-0">Container Width</h5>



                                         <div class="btn-group radio" role="group">

                                             <input type="radio" class="btn-check" name="data-container-position"

                                                 id="container-width-fixed" value="fixed">

                                             <label class="btn btn-sm btn-soft-primary w-sm"

                                                 for="container-width-fixed">Full</label>



                                             <input type="radio" class="btn-check" name="data-container-position"

                                                 id="container-width-scrollable" value="scrollable">

                                             <label class="btn btn-sm btn-soft-primary w-sm ms-0"

                                                 for="container-width-scrollable">Boxed</label>

                                         </div>

                                     </div>

                                 </div>



                                 <div class="p-3 border-bottom border-dashed d-none">

                                     <div class="d-flex justify-content-between align-items-center">

                                         <h5 class="fs-16 fw-bold mb-0">Layout Position</h5>



                                         <div class="btn-group radio" role="group">

                                             <input type="radio" class="btn-check" name="data-layout-position"

                                                 id="layout-position-fixed" value="fixed">

                                             <label class="btn btn-sm btn-soft-primary w-sm"

                                                 for="layout-position-fixed">Fixed</label>



                                             <input type="radio" class="btn-check" name="data-layout-position"

                                                 id="layout-position-scrollable" value="scrollable">

                                             <label class="btn btn-sm btn-soft-primary w-sm ms-0"

                                                 for="layout-position-scrollable">Scrollable</label>

                                         </div>

                                     </div>

                                 </div>

                             </div>

                         </div>

                     </div>

                 </div>

                 <div class="simplebar-placeholder" style="width: 399px; height: 991px;"></div>

             </div>

             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">

                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>

             </div>

             <div class="simplebar-track simplebar-vertical" style="visibility: visible;">

                 <div class="simplebar-scrollbar"

                     style="height: 364px; transform: translate3d(0px, 0px, 0px); display: block;"></div>

             </div>

         </div>





     </div>


<?php endif; ?>
     <!-- Vendor js -->

     <script src="<?php echo e(asset('assets/user/js/vendor.min.js.download')); ?>"></script>



     <!-- App js -->

     <script src="<?php echo e(asset('assets/user/js/app.js.download')); ?>"></script>



     <!-- Apex Chart js -->

     <script src="<?php echo e(asset('assets/user/js/apexcharts.min.js.download')); ?>"></script>



     <!-- Projects Analytics Dashboard App js -->

     <script src="<?php echo e(asset('assets/user/js/dashboard.js.download')); ?>"></script>



<?php echo $__env->yieldPushContent('scripts'); ?>

     </body>



     </html><?php /**PATH /home2/predictormt/public_html/resources/views/user/include/footer.blade.php ENDPATH**/ ?>