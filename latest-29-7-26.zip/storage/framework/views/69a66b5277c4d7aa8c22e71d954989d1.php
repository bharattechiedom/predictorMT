<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Companies - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 5px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }
        .sidebar .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .main-content {
            padding: 2rem;
        }
        .navbar-custom {
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .nav-section {
            margin-bottom: 1.5rem;
        }
        .nav-section-title {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
            padding: 0 1rem;
        }
        .table-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            border: none;
        }
        .btn-action {
            padding: 0.25rem 0.5rem;
            margin: 0 2px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar">
                    <div class="p-3">
                        <h4 class="text-center mb-4">
                            <i class="fas fa-shield-alt me-2"></i>
                            Admin Panel
                        </h4>
                        <nav class="nav flex-column">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="fas fa-tachometer-alt me-2"></i>
                                Dashboard
                            </a>
                            
                            <div class="nav-section">
                                <h6 class="nav-section-title">Core Data</h6>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.companies.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.companies.index')); ?>">
                                    <i class="fas fa-building me-2"></i>
                                    Companies
                                </a>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.plans.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.plans.index')); ?>">
                                    <i class="fas fa-tags me-2"></i>
                                    Plans
                                </a>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>">
                                    <i class="fas fa-users me-2"></i>
                                    Users
                                </a>
                            </div>

                            <div class="nav-section">
                                <h6 class="nav-section-title">Machines & Sensors</h6>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.machines.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.machines.index')); ?>">
                                    <i class="fas fa-cogs me-2"></i>
                                    Machines
                                </a>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.sensors.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.sensors.index')); ?>">
                                    <i class="fas fa-microchip me-2"></i>
                                    Sensors
                                </a>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.sensor-readings.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.sensor-readings.index')); ?>">
                                    <i class="fas fa-chart-line me-2"></i>
                                    Sensor Readings
                                </a>
                            </div>

                            <div class="nav-section">
                                <h6 class="nav-section-title">Predictions & Alerts</h6>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.predictions.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.predictions.index')); ?>">
                                    <i class="fas fa-brain me-2"></i>
                                    Predictions
                                </a>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.alerts.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.alerts.index')); ?>">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    Alerts
                                </a>
                            </div>

                            <div class="nav-section">
                                <h6 class="nav-section-title">Maintenance</h6>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.maintenance-tasks.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.maintenance-tasks.index')); ?>">
                                    <i class="fas fa-wrench me-2"></i>
                                    Maintenance Tasks
                                </a>
                            </div>

                            <div class="nav-section">
                                <h6 class="nav-section-title">Billing & Support</h6>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.subscriptions.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.subscriptions.index')); ?>">
                                    <i class="fas fa-credit-card me-2"></i>
                                    Subscriptions
                                </a>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.invoices.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.invoices.index')); ?>">
                                    <i class="fas fa-file-invoice me-2"></i>
                                    Invoices
                                </a>
                                <a class="nav-link <?php echo e(request()->routeIs('admin.tickets.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.tickets.index')); ?>">
                                    <i class="fas fa-ticket-alt me-2"></i>
                                    Support Tickets
                                </a>
                            </div>

                            <hr class="my-3" style="border-color: rgba(255,255,255,0.2);">
                            <a class="nav-link" href="<?php echo e(route('admin.logout')); ?>" 
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt me-2"></i>
                                Logout
                            </a>
                        </nav>
                    </div>
                </div>
            </div><?php /**PATH D:\xampp\htdocs\predictormt\resources\views/admin/include/header.blade.php ENDPATH**/ ?>