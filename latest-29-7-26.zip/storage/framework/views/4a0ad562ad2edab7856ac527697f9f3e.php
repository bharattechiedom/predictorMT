<!doctype html>



<html lang="en">

<head>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="shortcut icon" href="<?php echo e(asset('assets/user/images/favicon.ico')); ?>" />

  <title>PredictorMT Tech Solution INC.</title>

  <link href="<?php echo e(asset('public/assets/user/css/all.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('public/assets/user/css/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('public/assets/user/css/bootstrap.min.css')); ?>" rel="stylesheet">

  <link href="<?php echo e(asset('public/assets/user/css/animate.css')); ?>" rel="stylesheet">

  <link href="<?php echo e(asset('public/assets/user/css/owl-carousel.css')); ?>" rel="stylesheet">

  <link href="<?php echo e(asset('public/assets/user/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('public/assets/user/css/responsive.css')); ?>" rel="stylesheet">
</head>

<body>



  <header class="header_top">

    <nav class="navbar navbar-expand-lg">
      <div class="container headr justify-content-between">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="<?php echo e(asset('public/assets/user/images/logo.png')); ?>" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNavDropdown">

          <?php

          $currentRoute = Request::route()->getName();

          ?>
          <ul class="navbar-nav">
            <li class="nav-item"> <a class="nav-link <?php echo e($currentRoute == '/' ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Home</a> </li>
            <li class="nav-item"> <a class="nav-link <?php echo e($currentRoute == 'about' ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">About</a> </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle <?php echo e($currentRoute == 'product' ? 'active' : ''); ?>"
                href="<?php echo e(route('product')); ?>"
                data-toggle="dropdown"
                role="button"
                aria-haspopup="true"
                aria-expanded="false">
                Product
              </a>

              <ul class="dropdown-menu dropdown-menu-dark">
                <li><a class="dropdown-item" href="<?php echo e(route('product')); ?>">Maintanance & Solution</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('product')); ?>">Industrial Electronics</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('product')); ?>">Data & Analytics Software</a></li>

              </ul>
            </li>




            <li class="nav-item"> <a class="nav-link <?php echo e($currentRoute == 'solution' ? 'active' : ''); ?>" href="<?php echo e(route('solution')); ?>">Solution</a> </li>

            <li class="nav-item"> <a class="nav-link <?php echo e($currentRoute == 'service' ? 'active' : ''); ?>" href="<?php echo e(route('service')); ?>">Services</a> </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle <?php echo e($currentRoute == 'industries' ? 'active' : ''); ?>"
                href="<?php echo e(route('industries')); ?>"
                data-toggle="dropdown"
                role="button"
                aria-haspopup="true"
                aria-expanded="false">
                Industries
              </a>

              <ul class="dropdown-menu dropdown-menu-dark">
                <li><a class="dropdown-item" href="<?php echo e(route('industries')); ?>">Mining
                    Exploration</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('industries')); ?>">Trucking
                    Companies</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('industries')); ?>">Our
                    Manufacturers</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('industries')); ?>">Agriculture
                    Equipment</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('industries')); ?>">Our
                    Warehousing</a></li>
              </ul>
            </li>


            <li class="nav-item"> <a class="nav-link <?php echo e($currentRoute == 'why_predictor' ? 'active' : ''); ?>" href="<?php echo e(route('why_predictor')); ?>">Why PredictorMT</a> </li>

            <li class="nav-item"> <a class="nav-link <?php echo e($currentRoute == 'contact' ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">Contact Us</a> </li>


          </ul>

        </div>
        <div class="btn_grp">

          <a class="btnLogin" href="<?php echo e(route('demo')); ?>">Request A Demo</a>




          <?php if(auth()->guard()->check()): ?>

          <div class="dropdown">
            <button class="btn_join dropdown-toggle acc-btn"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              My Account
            </button>

            <ul class="dropdown-menu dropdown-menu-end accountDropdown">
              <li>
                <a class="dropdown-item" href="<?php echo e(route('user.dashboard')); ?>">
                  Dashboard
                </a>
              </li>
              <li>
                <form method="POST" action="<?php echo e(route('user.logout')); ?>">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="dropdown-item logout">
                    Logout
                  </button>
                </form>
              </li>
            </ul>
          </div>


          <?php else: ?>

          <a href="<?php echo e(route('signin')); ?>" class="btnLogin btn_join">

            <i class="fa fa-user" style="color: white; margin-right: 6px;"></i> Sign In

          </a>

          <?php endif; ?>



        </div>
    </nav>
    </div>

  </header><?php /**PATH /home2/predictormt/public_html/UAT/resources/views/include/header.blade.php ENDPATH**/ ?>