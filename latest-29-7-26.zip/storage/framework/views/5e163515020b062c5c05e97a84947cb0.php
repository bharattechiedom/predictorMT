<?php $page_title = "predictorMt - profile"; ?>



<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <!-- Begin page -->

    <div class="wrapper active">

        <div class="page-content">

            <div class="myaccountPage p-4">

             

                <div class="dashboardForms py-3">
                    <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">

    <h4 class="header-title mb-0 text-white">Update Your Profile</h4>


  </div>
  <div class="card-body bg-white">




                    <?php if($errors->any()): ?>

                        <div class="alert alert-danger alert-dismissible fade show" role="alert">

                            <ul class="mb-0">

                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li><?php echo e($error); ?></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>

                        </div>

                    <?php endif; ?>



                    <?php if(session('success')): ?>

                        <div class="alert alert-success alert-dismissible fade show" role="alert">

                            <?php echo e(session('success')); ?>


                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>

                        </div>

                    <?php endif; ?>



                    <form method="POST" action="<?php echo e(route('user.profile.update')); ?>" id="profile-form">

                        <?php echo csrf_field(); ?>

                        <div class="row">

                            <div class="col-md-6">

                                <div class="form-group">

                                    <label for="first_name">Full Name</label>

                                    <input 

                                        type="text" 

                                        name="first_name" 

                                        id="first_name" 

                                        placeholder="Enter First Name"

                                        class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 

                                        value="<?php echo e(explode(' ', $user->name)[0] ?? ''); ?>"

                                        required>

                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback d-block"><?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                            

                            <div class="col-md-6">

                                <div class="form-group">

                                    <label for="email">Email</label>

                                    <input 

                                        type="email" 

                                        name="email" 

                                        id="email" 

                                        placeholder="Enter your email"

                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 

                                        value="<?php echo e($user->email); ?>"

                                        required>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback d-block"><?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="form-group">

                                    <label for="phone">Phone No</label>

                                    <input 

                                        type="tel" 

                                        name="phone" 

                                        id="phone" 

                                        placeholder="Enter your Phone"

                                        class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 

                                        value="<?php echo e($user->phone); ?>"

                                        required>

                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback d-block"><?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                        </div>



                        <div class="row">

                            <div class="col-md-6">

                                <div class="form-group">

                                    <label for="country">Country</label>

                                    <select id="country" name="country" class="form-control <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                        <option value="">Select Country</option>

                                        <option value="Afghanistan" <?php echo e($user->country === 'Afghanistan' ? 'selected' : ''); ?>>Afghanistan</option>

                                        <option value="Albania" <?php echo e($user->country === 'Albania' ? 'selected' : ''); ?>>Albania</option>

                                        <option value="Algeria" <?php echo e($user->country === 'Algeria' ? 'selected' : ''); ?>>Algeria</option>

                                        <option value="Andorra" <?php echo e($user->country === 'Andorra' ? 'selected' : ''); ?>>Andorra</option>

                                        <option value="Angola" <?php echo e($user->country === 'Angola' ? 'selected' : ''); ?>>Angola</option>

                                        <option value="Antigua and Barbuda" <?php echo e($user->country === 'Antigua and Barbuda' ? 'selected' : ''); ?>>Antigua and Barbuda</option>

                                        <option value="Argentina" <?php echo e($user->country === 'Argentina' ? 'selected' : ''); ?>>Argentina</option>

                                        <option value="Armenia" <?php echo e($user->country === 'Armenia' ? 'selected' : ''); ?>>Armenia</option>

                                        <option value="Australia" <?php echo e($user->country === 'Australia' ? 'selected' : ''); ?>>Australia</option>

                                        <option value="Austria" <?php echo e($user->country === 'Austria' ? 'selected' : ''); ?>>Austria</option>

                                        <option value="Azerbaijan" <?php echo e($user->country === 'Azerbaijan' ? 'selected' : ''); ?>>Azerbaijan</option>

                                        <option value="Bahamas" <?php echo e($user->country === 'Bahamas' ? 'selected' : ''); ?>>Bahamas</option>

                                        <option value="Bahrain" <?php echo e($user->country === 'Bahrain' ? 'selected' : ''); ?>>Bahrain</option>

                                        <option value="Bangladesh" <?php echo e($user->country === 'Bangladesh' ? 'selected' : ''); ?>>Bangladesh</option>

                                        <option value="Barbados" <?php echo e($user->country === 'Barbados' ? 'selected' : ''); ?>>Barbados</option>

                                        <option value="Belarus" <?php echo e($user->country === 'Belarus' ? 'selected' : ''); ?>>Belarus</option>

                                        <option value="Belgium" <?php echo e($user->country === 'Belgium' ? 'selected' : ''); ?>>Belgium</option>

                                        <option value="Belize" <?php echo e($user->country === 'Belize' ? 'selected' : ''); ?>>Belize</option>

                                        <option value="Benin" <?php echo e($user->country === 'Benin' ? 'selected' : ''); ?>>Benin</option>

                                        <option value="Bhutan" <?php echo e($user->country === 'Bhutan' ? 'selected' : ''); ?>>Bhutan</option>

                                        <option value="Bolivia" <?php echo e($user->country === 'Bolivia' ? 'selected' : ''); ?>>Bolivia</option>

                                        <option value="Bosnia and Herzegovina" <?php echo e($user->country === 'Bosnia and Herzegovina' ? 'selected' : ''); ?>>Bosnia and Herzegovina</option>

                                        <option value="Botswana" <?php echo e($user->country === 'Botswana' ? 'selected' : ''); ?>>Botswana</option>

                                        <option value="Brazil" <?php echo e($user->country === 'Brazil' ? 'selected' : ''); ?>>Brazil</option>

                                        <option value="Brunei" <?php echo e($user->country === 'Brunei' ? 'selected' : ''); ?>>Brunei</option>

                                        <option value="Bulgaria" <?php echo e($user->country === 'Bulgaria' ? 'selected' : ''); ?>>Bulgaria</option>

                                        <option value="Burkina Faso" <?php echo e($user->country === 'Burkina Faso' ? 'selected' : ''); ?>>Burkina Faso</option>

                                        <option value="Burundi" <?php echo e($user->country === 'Burundi' ? 'selected' : ''); ?>>Burundi</option>

                                        <option value="Cambodia" <?php echo e($user->country === 'Cambodia' ? 'selected' : ''); ?>>Cambodia</option>

                                        <option value="Cameroon" <?php echo e($user->country === 'Cameroon' ? 'selected' : ''); ?>>Cameroon</option>

                                        <option value="Canada" <?php echo e($user->country === 'Canada' ? 'selected' : ''); ?>>Canada</option>

                                        <option value="Cape Verde" <?php echo e($user->country === 'Cape Verde' ? 'selected' : ''); ?>>Cape Verde</option>

                                        <option value="Central African Republic" <?php echo e($user->country === 'Central African Republic' ? 'selected' : ''); ?>>Central African Republic</option>

                                        <option value="Chad" <?php echo e($user->country === 'Chad' ? 'selected' : ''); ?>>Chad</option>

                                        <option value="Chile" <?php echo e($user->country === 'Chile' ? 'selected' : ''); ?>>Chile</option>

                                        <option value="China" <?php echo e($user->country === 'China' ? 'selected' : ''); ?>>China</option>

                                        <option value="Colombia" <?php echo e($user->country === 'Colombia' ? 'selected' : ''); ?>>Colombia</option>

                                        <option value="Comoros" <?php echo e($user->country === 'Comoros' ? 'selected' : ''); ?>>Comoros</option>

                                        <option value="Congo" <?php echo e($user->country === 'Congo' ? 'selected' : ''); ?>>Congo</option>

                                        <option value="Costa Rica" <?php echo e($user->country === 'Costa Rica' ? 'selected' : ''); ?>>Costa Rica</option>

                                        <option value="Croatia" <?php echo e($user->country === 'Croatia' ? 'selected' : ''); ?>>Croatia</option>

                                        <option value="Cuba" <?php echo e($user->country === 'Cuba' ? 'selected' : ''); ?>>Cuba</option>

                                        <option value="Cyprus" <?php echo e($user->country === 'Cyprus' ? 'selected' : ''); ?>>Cyprus</option>

                                        <option value="Czech Republic" <?php echo e($user->country === 'Czech Republic' ? 'selected' : ''); ?>>Czech Republic</option>

                                        <option value="Denmark" <?php echo e($user->country === 'Denmark' ? 'selected' : ''); ?>>Denmark</option>

                                        <option value="Djibouti" <?php echo e($user->country === 'Djibouti' ? 'selected' : ''); ?>>Djibouti</option>

                                        <option value="Dominica" <?php echo e($user->country === 'Dominica' ? 'selected' : ''); ?>>Dominica</option>

                                        <option value="Dominican Republic" <?php echo e($user->country === 'Dominican Republic' ? 'selected' : ''); ?>>Dominican Republic</option>

                                        <option value="Ecuador" <?php echo e($user->country === 'Ecuador' ? 'selected' : ''); ?>>Ecuador</option>

                                        <option value="Egypt" <?php echo e($user->country === 'Egypt' ? 'selected' : ''); ?>>Egypt</option>

                                        <option value="El Salvador" <?php echo e($user->country === 'El Salvador' ? 'selected' : ''); ?>>El Salvador</option>

                                        <option value="Equatorial Guinea" <?php echo e($user->country === 'Equatorial Guinea' ? 'selected' : ''); ?>>Equatorial Guinea</option>

                                        <option value="Eritrea" <?php echo e($user->country === 'Eritrea' ? 'selected' : ''); ?>>Eritrea</option>

                                        <option value="Estonia" <?php echo e($user->country === 'Estonia' ? 'selected' : ''); ?>>Estonia</option>

                                        <option value="Ethiopia" <?php echo e($user->country === 'Ethiopia' ? 'selected' : ''); ?>>Ethiopia</option>

                                        <option value="Fiji" <?php echo e($user->country === 'Fiji' ? 'selected' : ''); ?>>Fiji</option>

                                        <option value="Finland" <?php echo e($user->country === 'Finland' ? 'selected' : ''); ?>>Finland</option>

                                        <option value="France" <?php echo e($user->country === 'France' ? 'selected' : ''); ?>>France</option>

                                        <option value="Gabon" <?php echo e($user->country === 'Gabon' ? 'selected' : ''); ?>>Gabon</option>

                                        <option value="Gambia" <?php echo e($user->country === 'Gambia' ? 'selected' : ''); ?>>Gambia</option>

                                        <option value="Georgia" <?php echo e($user->country === 'Georgia' ? 'selected' : ''); ?>>Georgia</option>

                                        <option value="Germany" <?php echo e($user->country === 'Germany' ? 'selected' : ''); ?>>Germany</option>

                                        <option value="Ghana" <?php echo e($user->country === 'Ghana' ? 'selected' : ''); ?>>Ghana</option>

                                        <option value="Greece" <?php echo e($user->country === 'Greece' ? 'selected' : ''); ?>>Greece</option>

                                        <option value="Grenada" <?php echo e($user->country === 'Grenada' ? 'selected' : ''); ?>>Grenada</option>

                                        <option value="Guatemala" <?php echo e($user->country === 'Guatemala' ? 'selected' : ''); ?>>Guatemala</option>

                                        <option value="Guinea" <?php echo e($user->country === 'Guinea' ? 'selected' : ''); ?>>Guinea</option>

                                        <option value="Guinea-Bissau" <?php echo e($user->country === 'Guinea-Bissau' ? 'selected' : ''); ?>>Guinea-Bissau</option>

                                        <option value="Guyana" <?php echo e($user->country === 'Guyana' ? 'selected' : ''); ?>>Guyana</option>

                                        <option value="Haiti" <?php echo e($user->country === 'Haiti' ? 'selected' : ''); ?>>Haiti</option>

                                        <option value="Honduras" <?php echo e($user->country === 'Honduras' ? 'selected' : ''); ?>>Honduras</option>

                                        <option value="Hungary" <?php echo e($user->country === 'Hungary' ? 'selected' : ''); ?>>Hungary</option>

                                        <option value="Iceland" <?php echo e($user->country === 'Iceland' ? 'selected' : ''); ?>>Iceland</option>

                                        <option value="India" <?php echo e($user->country === 'India' ? 'selected' : ''); ?>>India</option>

                                        <option value="Indonesia" <?php echo e($user->country === 'Indonesia' ? 'selected' : ''); ?>>Indonesia</option>

                                        <option value="Iran" <?php echo e($user->country === 'Iran' ? 'selected' : ''); ?>>Iran</option>

                                        <option value="Iraq" <?php echo e($user->country === 'Iraq' ? 'selected' : ''); ?>>Iraq</option>

                                        <option value="Ireland" <?php echo e($user->country === 'Ireland' ? 'selected' : ''); ?>>Ireland</option>

                                        <option value="Israel" <?php echo e($user->country === 'Israel' ? 'selected' : ''); ?>>Israel</option>

                                        <option value="Italy" <?php echo e($user->country === 'Italy' ? 'selected' : ''); ?>>Italy</option>

                                        <option value="Jamaica" <?php echo e($user->country === 'Jamaica' ? 'selected' : ''); ?>>Jamaica</option>

                                        <option value="Japan" <?php echo e($user->country === 'Japan' ? 'selected' : ''); ?>>Japan</option>

                                        <option value="Jordan" <?php echo e($user->country === 'Jordan' ? 'selected' : ''); ?>>Jordan</option>

                                        <option value="Kazakhstan" <?php echo e($user->country === 'Kazakhstan' ? 'selected' : ''); ?>>Kazakhstan</option>

                                        <option value="Kenya" <?php echo e($user->country === 'Kenya' ? 'selected' : ''); ?>>Kenya</option>

                                        <option value="Kiribati" <?php echo e($user->country === 'Kiribati' ? 'selected' : ''); ?>>Kiribati</option>

                                        <option value="Kuwait" <?php echo e($user->country === 'Kuwait' ? 'selected' : ''); ?>>Kuwait</option>

                                        <option value="Kyrgyzstan" <?php echo e($user->country === 'Kyrgyzstan' ? 'selected' : ''); ?>>Kyrgyzstan</option>

                                        <option value="Laos" <?php echo e($user->country === 'Laos' ? 'selected' : ''); ?>>Laos</option>

                                        <option value="Latvia" <?php echo e($user->country === 'Latvia' ? 'selected' : ''); ?>>Latvia</option>

                                        <option value="Lebanon" <?php echo e($user->country === 'Lebanon' ? 'selected' : ''); ?>>Lebanon</option>

                                        <option value="Lesotho" <?php echo e($user->country === 'Lesotho' ? 'selected' : ''); ?>>Lesotho</option>

                                        <option value="Liberia" <?php echo e($user->country === 'Liberia' ? 'selected' : ''); ?>>Liberia</option>

                                        <option value="Libya" <?php echo e($user->country === 'Libya' ? 'selected' : ''); ?>>Libya</option>

                                        <option value="Liechtenstein" <?php echo e($user->country === 'Liechtenstein' ? 'selected' : ''); ?>>Liechtenstein</option>

                                        <option value="Lithuania" <?php echo e($user->country === 'Lithuania' ? 'selected' : ''); ?>>Lithuania</option>

                                        <option value="Luxembourg" <?php echo e($user->country === 'Luxembourg' ? 'selected' : ''); ?>>Luxembourg</option>

                                        <option value="Madagascar" <?php echo e($user->country === 'Madagascar' ? 'selected' : ''); ?>>Madagascar</option>

                                        <option value="Malawi" <?php echo e($user->country === 'Malawi' ? 'selected' : ''); ?>>Malawi</option>

                                        <option value="Malaysia" <?php echo e($user->country === 'Malaysia' ? 'selected' : ''); ?>>Malaysia</option>

                                        <option value="Maldives" <?php echo e($user->country === 'Maldives' ? 'selected' : ''); ?>>Maldives</option>

                                        <option value="Mali" <?php echo e($user->country === 'Mali' ? 'selected' : ''); ?>>Mali</option>

                                        <option value="Malta" <?php echo e($user->country === 'Malta' ? 'selected' : ''); ?>>Malta</option>

                                        <option value="Marshall Islands" <?php echo e($user->country === 'Marshall Islands' ? 'selected' : ''); ?>>Marshall Islands</option>

                                        <option value="Mauritania" <?php echo e($user->country === 'Mauritania' ? 'selected' : ''); ?>>Mauritania</option>

                                        <option value="Mauritius" <?php echo e($user->country === 'Mauritius' ? 'selected' : ''); ?>>Mauritius</option>

                                        <option value="Mexico" <?php echo e($user->country === 'Mexico' ? 'selected' : ''); ?>>Mexico</option>

                                        <option value="Micronesia" <?php echo e($user->country === 'Micronesia' ? 'selected' : ''); ?>>Micronesia</option>

                                        <option value="Moldova" <?php echo e($user->country === 'Moldova' ? 'selected' : ''); ?>>Moldova</option>

                                        <option value="Monaco" <?php echo e($user->country === 'Monaco' ? 'selected' : ''); ?>>Monaco</option>

                                        <option value="Mongolia" <?php echo e($user->country === 'Mongolia' ? 'selected' : ''); ?>>Mongolia</option>

                                        <option value="Montenegro" <?php echo e($user->country === 'Montenegro' ? 'selected' : ''); ?>>Montenegro</option>

                                        <option value="Morocco" <?php echo e($user->country === 'Morocco' ? 'selected' : ''); ?>>Morocco</option>

                                        <option value="Mozambique" <?php echo e($user->country === 'Mozambique' ? 'selected' : ''); ?>>Mozambique</option>

                                        <option value="Myanmar" <?php echo e($user->country === 'Myanmar' ? 'selected' : ''); ?>>Myanmar</option>

                                        <option value="Namibia" <?php echo e($user->country === 'Namibia' ? 'selected' : ''); ?>>Namibia</option>

                                        <option value="Nauru" <?php echo e($user->country === 'Nauru' ? 'selected' : ''); ?>>Nauru</option>

                                        <option value="Nepal" <?php echo e($user->country === 'Nepal' ? 'selected' : ''); ?>>Nepal</option>

                                        <option value="Netherlands" <?php echo e($user->country === 'Netherlands' ? 'selected' : ''); ?>>Netherlands</option>

                                        <option value="New Zealand" <?php echo e($user->country === 'New Zealand' ? 'selected' : ''); ?>>New Zealand</option>

                                        <option value="Nicaragua" <?php echo e($user->country === 'Nicaragua' ? 'selected' : ''); ?>>Nicaragua</option>

                                        <option value="Niger" <?php echo e($user->country === 'Niger' ? 'selected' : ''); ?>>Niger</option>

                                        <option value="Nigeria" <?php echo e($user->country === 'Nigeria' ? 'selected' : ''); ?>>Nigeria</option>

                                        <option value="North Korea" <?php echo e($user->country === 'North Korea' ? 'selected' : ''); ?>>North Korea</option>

                                        <option value="North Macedonia" <?php echo e($user->country === 'North Macedonia' ? 'selected' : ''); ?>>North Macedonia</option>

                                        <option value="Norway" <?php echo e($user->country === 'Norway' ? 'selected' : ''); ?>>Norway</option>

                                        <option value="Oman" <?php echo e($user->country === 'Oman' ? 'selected' : ''); ?>>Oman</option>

                                        <option value="Pakistan" <?php echo e($user->country === 'Pakistan' ? 'selected' : ''); ?>>Pakistan</option>

                                        <option value="Palau" <?php echo e($user->country === 'Palau' ? 'selected' : ''); ?>>Palau</option>

                                        <option value="Palestine" <?php echo e($user->country === 'Palestine' ? 'selected' : ''); ?>>Palestine</option>

                                        <option value="Panama" <?php echo e($user->country === 'Panama' ? 'selected' : ''); ?>>Panama</option>

                                        <option value="Papua New Guinea" <?php echo e($user->country === 'Papua New Guinea' ? 'selected' : ''); ?>>Papua New Guinea</option>

                                        <option value="Paraguay" <?php echo e($user->country === 'Paraguay' ? 'selected' : ''); ?>>Paraguay</option>

                                        <option value="Peru" <?php echo e($user->country === 'Peru' ? 'selected' : ''); ?>>Peru</option>

                                        <option value="Philippines" <?php echo e($user->country === 'Philippines' ? 'selected' : ''); ?>>Philippines</option>

                                        <option value="Poland" <?php echo e($user->country === 'Poland' ? 'selected' : ''); ?>>Poland</option>

                                        <option value="Portugal" <?php echo e($user->country === 'Portugal' ? 'selected' : ''); ?>>Portugal</option>

                                        <option value="Qatar" <?php echo e($user->country === 'Qatar' ? 'selected' : ''); ?>>Qatar</option>

                                        <option value="Romania" <?php echo e($user->country === 'Romania' ? 'selected' : ''); ?>>Romania</option>

                                        <option value="Russia" <?php echo e($user->country === 'Russia' ? 'selected' : ''); ?>>Russia</option>

                                        <option value="Rwanda" <?php echo e($user->country === 'Rwanda' ? 'selected' : ''); ?>>Rwanda</option>

                                        <option value="Saint Kitts and Nevis" <?php echo e($user->country === 'Saint Kitts and Nevis' ? 'selected' : ''); ?>>Saint Kitts and Nevis</option>

                                        <option value="Saint Lucia" <?php echo e($user->country === 'Saint Lucia' ? 'selected' : ''); ?>>Saint Lucia</option>

                                        <option value="Saint Vincent and the Grenadines" <?php echo e($user->country === 'Saint Vincent and the Grenadines' ? 'selected' : ''); ?>>Saint Vincent and the Grenadines</option>

                                        <option value="Samoa" <?php echo e($user->country === 'Samoa' ? 'selected' : ''); ?>>Samoa</option>

                                        <option value="San Marino" <?php echo e($user->country === 'San Marino' ? 'selected' : ''); ?>>San Marino</option>

                                        <option value="Sao Tome and Principe" <?php echo e($user->country === 'Sao Tome and Principe' ? 'selected' : ''); ?>>Sao Tome and Principe</option>

                                        <option value="Saudi Arabia" <?php echo e($user->country === 'Saudi Arabia' ? 'selected' : ''); ?>>Saudi Arabia</option>

                                        <option value="Senegal" <?php echo e($user->country === 'Senegal' ? 'selected' : ''); ?>>Senegal</option>

                                        <option value="Serbia" <?php echo e($user->country === 'Serbia' ? 'selected' : ''); ?>>Serbia</option>

                                        <option value="Seychelles" <?php echo e($user->country === 'Seychelles' ? 'selected' : ''); ?>>Seychelles</option>

                                        <option value="Sierra Leone" <?php echo e($user->country === 'Sierra Leone' ? 'selected' : ''); ?>>Sierra Leone</option>

                                        <option value="Singapore" <?php echo e($user->country === 'Singapore' ? 'selected' : ''); ?>>Singapore</option>

                                        <option value="Slovakia" <?php echo e($user->country === 'Slovakia' ? 'selected' : ''); ?>>Slovakia</option>

                                        <option value="Slovenia" <?php echo e($user->country === 'Slovenia' ? 'selected' : ''); ?>>Slovenia</option>

                                        <option value="Solomon Islands" <?php echo e($user->country === 'Solomon Islands' ? 'selected' : ''); ?>>Solomon Islands</option>

                                        <option value="Somalia" <?php echo e($user->country === 'Somalia' ? 'selected' : ''); ?>>Somalia</option>

                                        <option value="South Africa" <?php echo e($user->country === 'South Africa' ? 'selected' : ''); ?>>South Africa</option>

                                        <option value="South Korea" <?php echo e($user->country === 'South Korea' ? 'selected' : ''); ?>>South Korea</option>

                                        <option value="South Sudan" <?php echo e($user->country === 'South Sudan' ? 'selected' : ''); ?>>South Sudan</option>

                                        <option value="Spain" <?php echo e($user->country === 'Spain' ? 'selected' : ''); ?>>Spain</option>

                                        <option value="Sri Lanka" <?php echo e($user->country === 'Sri Lanka' ? 'selected' : ''); ?>>Sri Lanka</option>

                                        <option value="Sudan" <?php echo e($user->country === 'Sudan' ? 'selected' : ''); ?>>Sudan</option>

                                        <option value="Suriname" <?php echo e($user->country === 'Suriname' ? 'selected' : ''); ?>>Suriname</option>

                                        <option value="Sweden" <?php echo e($user->country === 'Sweden' ? 'selected' : ''); ?>>Sweden</option>

                                        <option value="Switzerland" <?php echo e($user->country === 'Switzerland' ? 'selected' : ''); ?>>Switzerland</option>

                                        <option value="Syria" <?php echo e($user->country === 'Syria' ? 'selected' : ''); ?>>Syria</option>

                                        <option value="Taiwan" <?php echo e($user->country === 'Taiwan' ? 'selected' : ''); ?>>Taiwan</option>

                                        <option value="Tajikistan" <?php echo e($user->country === 'Tajikistan' ? 'selected' : ''); ?>>Tajikistan</option>

                                        <option value="Tanzania" <?php echo e($user->country === 'Tanzania' ? 'selected' : ''); ?>>Tanzania</option>

                                        <option value="Thailand" <?php echo e($user->country === 'Thailand' ? 'selected' : ''); ?>>Thailand</option>

                                        <option value="Timor-Leste" <?php echo e($user->country === 'Timor-Leste' ? 'selected' : ''); ?>>Timor-Leste</option>

                                        <option value="Togo" <?php echo e($user->country === 'Togo' ? 'selected' : ''); ?>>Togo</option>

                                        <option value="Tonga" <?php echo e($user->country === 'Tonga' ? 'selected' : ''); ?>>Tonga</option>

                                        <option value="Trinidad and Tobago" <?php echo e($user->country === 'Trinidad and Tobago' ? 'selected' : ''); ?>>Trinidad and Tobago</option>

                                        <option value="Tunisia" <?php echo e($user->country === 'Tunisia' ? 'selected' : ''); ?>>Tunisia</option>

                                        <option value="Turkey" <?php echo e($user->country === 'Turkey' ? 'selected' : ''); ?>>Turkey</option>

                                        <option value="Turkmenistan" <?php echo e($user->country === 'Turkmenistan' ? 'selected' : ''); ?>>Turkmenistan</option>

                                        <option value="Tuvalu" <?php echo e($user->country === 'Tuvalu' ? 'selected' : ''); ?>>Tuvalu</option>

                                        <option value="Uganda" <?php echo e($user->country === 'Uganda' ? 'selected' : ''); ?>>Uganda</option>

                                        <option value="Ukraine" <?php echo e($user->country === 'Ukraine' ? 'selected' : ''); ?>>Ukraine</option>

                                        <option value="United Arab Emirates" <?php echo e($user->country === 'United Arab Emirates' ? 'selected' : ''); ?>>United Arab Emirates</option>

                                        <option value="United Kingdom" <?php echo e($user->country === 'United Kingdom' ? 'selected' : ''); ?>>United Kingdom</option>

                                        <option value="United States" <?php echo e($user->country === 'United States' ? 'selected' : ''); ?>>United States</option>

                                        <option value="Uruguay" <?php echo e($user->country === 'Uruguay' ? 'selected' : ''); ?>>Uruguay</option>

                                        <option value="Uzbekistan" <?php echo e($user->country === 'Uzbekistan' ? 'selected' : ''); ?>>Uzbekistan</option>

                                        <option value="Vanuatu" <?php echo e($user->country === 'Vanuatu' ? 'selected' : ''); ?>>Vanuatu</option>

                                        <option value="Vatican City" <?php echo e($user->country === 'Vatican City' ? 'selected' : ''); ?>>Vatican City</option>

                                        <option value="Venezuela" <?php echo e($user->country === 'Venezuela' ? 'selected' : ''); ?>>Venezuela</option>

                                        <option value="Vietnam" <?php echo e($user->country === 'Vietnam' ? 'selected' : ''); ?>>Vietnam</option>

                                        <option value="Yemen" <?php echo e($user->country === 'Yemen' ? 'selected' : ''); ?>>Yemen</option>

                                        <option value="Zambia" <?php echo e($user->country === 'Zambia' ? 'selected' : ''); ?>>Zambia</option>

                                        <option value="Zimbabwe" <?php echo e($user->country === 'Zimbabwe' ? 'selected' : ''); ?>>Zimbabwe</option>

                                    </select>

                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback d-block"><?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="form-group">

                                    <label for="state">State/Province</label>

                                    <!-- Select shown when we have a mapping for the selected country -->

                                    <select id="stateSelect" class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                        <option value="">Select State/Province</option>

                                    </select>



                                    <!-- Text input fallback shown when no mapping exists -->

                                    <input type="text" id="stateText" class="form-control d-none" placeholder="Enter State/Province">



                                    <!-- Hidden field that will be submitted as `state` (populated by JS) -->

                                    <input type="hidden" name="state" id="stateHidden" value="<?php echo e($user->state ?? ''); ?>">



                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback d-block"><?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                        </div>



                        <div class="row mt-3">

                            <div class="col-md-6">

                                <div class="form-group">

                                    <label for="password">Password (leave blank to keep current)</label>

                                    <input 

                                        type="password" 

                                        name="password" 

                                        id="password" 

                                        placeholder="Enter new password"

                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback d-block"><?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="form-group">

                                    <label for="password_confirmation">Confirm Password</label>

                                    <input 

                                        type="password" 

                                        name="password_confirmation" 

                                        id="password_confirmation" 

                                        placeholder="Confirm password"

                                        class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback d-block"><?php echo e($message); ?></span>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>

                        </div>



                        <div class="row">

                            <div class="col-md-4 mt-3">

                                <button type="submit" class="lab-btn">Update Profile</button>

                            </div>

                        </div>



                    </form>

                </div>

            </div>

        </div>

        <!-- container -->

    </div>
    </div>
    </div>




<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<script>

    const statesByCountry = {

        "United States": ["Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York","North Carolina","North Dakota","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming"],

        "India": ["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Delhi","Puducherry"],

        "Australia": ["New South Wales","Queensland","South Australia","Tasmania","Victoria","Western Australia","Australian Capital Territory","Northern Territory"],

        "Canada": ["Alberta","British Columbia","Manitoba","New Brunswick","Newfoundland and Labrador","Nova Scotia","Ontario","Prince Edward Island","Quebec","Saskatchewan","Northwest Territories","Nunavut","Yukon"],

        "United Kingdom": ["England","Scotland","Wales","Northern Ireland"],

        "Germany": ["Baden-Württemberg","Bavaria","Berlin","Brandenburg","Bremen","Hamburg","Hesse","Lower Saxony","Mecklenburg-Vorpommern","North Rhine-Westphalia","Rhineland-Palatinate","Saarland","Saxony","Saxony-Anhalt","Schleswig-Holstein","Thuringia"],

        "France": ["Auvergne-Rhône-Alpes","Bourgogne-Franche-Comté","Brittany","Centre-Val de Loire","Corsica","Grand Est","Hauts-de-France","Île-de-France","Normandy","Nouvelle-Aquitaine","Occitanie","Pays de la Loire","Provence-Alpes-Côte d'Azur"],

        "Japan": ["Hokkaido","Aomori","Iwate","Miyagi","Akita","Yamagata","Fukushima","Ibaraki","Tochigi","Gunma","Saitama","Chiba","Tokyo","Kanagawa","Niigata","Toyama","Ishikawa","Fukui","Yamanashi","Nagano","Gifu","Shizuoka","Aichi","Mie","Shiga","Kyoto","Osaka","Hyogo","Nara","Wakayama","Tottori","Shimane","Okayama","Hiroshima","Yamaguchi","Tokushima","Kagawa","Ehime","Kochi","Fukuoka","Saga","Nagasaki","Kumamoto","Oita","Miyazaki","Kagoshima","Okinawa"],

        "China": ["Anhui","Beijing","Chongqing","Fujian","Gansu","Guangdong","Guangxi","Guizhou","Hainan","Hebei","Heilongjiang","Henan","Hubei","Hunan","Jiangsu","Jiangxi","Jilin","Liaoning","Inner Mongolia","Ningxia","Qinghai","Shaanxi","Shandong","Shanghai","Shanxi","Sichuan","Tianjin","Tibet","Xinjiang","Yunnan","Zhejiang"]

    };



    const countrySelect = document.getElementById('country');

    const stateSelect = document.getElementById('stateSelect');

    const stateText = document.getElementById('stateText');

    const stateHidden = document.getElementById('stateHidden');

    const profileForm = document.getElementById('profile-form');



    function showSelect() {

        stateSelect.classList.remove('d-none');

        stateSelect.previousElementSibling && stateSelect.previousElementSibling.classList && stateSelect.previousElementSibling.classList.remove('d-none');

        stateText.classList.add('d-none');

    }



    function showText() {

        stateText.classList.remove('d-none');

        stateSelect.classList.add('d-none');

    }



    function populateStatesForCountry(country, selectedState = '') {

        // clear existing options

        stateSelect.innerHTML = '<option value="">Select State/Province</option>';



        if (!country || !statesByCountry[country]) {

            // No mapping: show text input and keep user's existing state

            showText();

            if (selectedState) stateText.value = selectedState;

            return;

        }



        const states = statesByCountry[country];

        states.forEach(state => {

            const opt = document.createElement('option');

            opt.value = state;

            opt.textContent = state;

            if (selectedState && selectedState === state) opt.selected = true;

            stateSelect.appendChild(opt);

        });



        showSelect();

    }



    document.addEventListener('DOMContentLoaded', function() {

        const initialCountry = <?php echo json_encode($user->country ?? '', 15, 512) ?>;

        const initialState = <?php echo json_encode($user->state ?? '', 15, 512) ?>;



        if (initialCountry) {

            // ensure country select shows selected option (HTML may have already done this)

            const countryOption = Array.from(countrySelect.options).find(o => o.value === initialCountry);

            if (countryOption) countryOption.selected = true;

        }



        populateStatesForCountry(initialCountry, initialState);

    });



    if (countrySelect) {

        countrySelect.addEventListener('change', function(e) {

            populateStatesForCountry(e.target.value, '');

        });

    }



    // Before submit, copy visible state value into hidden `state` input

    if (profileForm) {

        profileForm.addEventListener('submit', function(e) {

            let value = '';

            if (!stateSelect.classList.contains('d-none')) {

                value = stateSelect.value || '';

            } else {

                value = stateText.value || '';

            }

            stateHidden.value = value;

        });

    }

</script>

<?php /**PATH /home2/predictormt/public_html/resources/views/user/profile.blade.php ENDPATH**/ ?>