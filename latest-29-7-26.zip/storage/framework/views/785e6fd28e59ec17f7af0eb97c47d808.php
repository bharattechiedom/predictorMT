<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

<nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">

                            <i class="fas fa-building me-2"></i>

                            Edit Machine

                        </span>

                        <div class="navbar-nav ms-auto">
                          <a href="<?php echo e(route('admin.machines.index')); ?>" class="btn themeBtn">Back</a>
                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">



  <?php if($errors->any()): ?>

    <div class="alert alert-danger">

      <ul class="mb-0">

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>

  <?php endif; ?>



  <form method="POST" action="<?php echo e(route('admin.machines.update', $machine)); ?>" class="bg-white p-3 border rounded">

    <?php echo csrf_field(); ?>

    <?php echo method_field('PUT'); ?>

    <div class="row g-3">

      <div class="col-md-6">

        <label class="form-label">Company</label>

        <select name="company_id" class="form-select" required>

          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($company->id); ?>" <?php echo e($machine->company_id==$company->id?'selected':''); ?>><?php echo e($company->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Name</label>

        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $machine->name)); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Type</label>

        <input type="text" name="machine_type" class="form-control" value="<?php echo e(old('machine_type', $machine->machine_type)); ?>">

      </div>

      <div class="col-md-6">

        <label class="form-label">Serial Number</label>

        <input type="text" name="serial_number" class="form-control" value="<?php echo e(old('serial_number', $machine->serial_number)); ?>">

      </div>

      <div class="col-md-6">

        <label class="form-label">Location</label>

        <input type="text" name="location" class="form-control" value="<?php echo e(old('location', $machine->location)); ?>">

      </div>

      <div class="col-md-6">

        <label class="form-label">Installed At</label>

        <input type="date" name="installed_at" class="form-control" value="<?php echo e(old('installed_at', optional($machine->installed_at)->format('Y-m-d'))); ?>">

      </div>

      <div class="col-md-6">

        <label class="form-label">Status</label>

        <select name="status" class="form-select" required>

          <?php $__currentLoopData = ['healthy','at_risk','critical','offline']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($status); ?>" <?php echo e($machine->status === $status ? 'selected' : ''); ?>><?php echo e($status); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

    </div>



    <div class="mt-3">

      <button type="submit" class="btn btn-primary">Update</button>

    </div>

  </form>

</div>

</div>

<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/machines/edit.blade.php ENDPATH**/ ?>