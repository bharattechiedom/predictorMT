<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your OTP Code</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <div style="background: linear-gradient(135deg, #51ade5 0%, #3c86d8 100%); padding: 30px; text-align: center;">
            <h1 style="color: #ffffff; margin: 0; font-size: 28px;">PredictorMT</h1>
            <p style="color: #ffffff; margin: 10px 0 0 0; font-size: 14px;">Secure Verification</p>
        </div>
        
        <div style="padding: 40px 30px;">
            <h2 style="color: #333333; margin: 0 0 20px 0; font-size: 24px;">Your OTP Code</h2>
            
            <p style="color: #666666; font-size: 16px; line-height: 1.6; margin: 0 0 30px 0;">
                Use the following One-Time Password (OTP) to complete your <?php echo e($type === 'login' ? 'sign in' : 'registration'); ?>:
            </p>
            
            <div style="background-color: #f8f9fa; border: 2px dashed #51ade5; border-radius: 8px; padding: 20px; text-align: center; margin: 0 0 30px 0;">
                <div style="font-size: 36px; font-weight: bold; color: #51ade5; letter-spacing: 8px;"><?php echo e($otp); ?></div>
            </div>
            
            <p style="color: #666666; font-size: 14px; line-height: 1.6; margin: 0 0 20px 0;">
                <strong>Important:</strong> This OTP will expire in <strong>5 minutes</strong>. Do not share this code with anyone.
            </p>
            
            <p style="color: #999999; font-size: 13px; line-height: 1.6; margin: 0;">
                If you didn't request this code, please ignore this email or contact our support team.
            </p>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 20px 30px; text-align: center; border-top: 1px solid #e9ecef;">
            <p style="color: #999999; font-size: 12px; margin: 0;">
                © <?php echo e(date('Y')); ?> PredictorMT. All rights reserved.
            </p>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\predictormt\resources\views/emails/otp.blade.php ENDPATH**/ ?>