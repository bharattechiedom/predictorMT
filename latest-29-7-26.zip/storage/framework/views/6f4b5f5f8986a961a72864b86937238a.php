<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">
Predictions
                        </span>

                        <div class="navbar-nav ms-auto ">
    <a href="<?php echo e(route('admin.predictions.create')); ?>" class="btn themeBtn">Add Prediction</a>

                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">




  <?php if(session('success')): ?>

    <div class="alert alert-success"><?php echo e(session('success')); ?></div>

  <?php endif; ?>



  <div class="table-responsive bg-white p-2">

    <table class="table table-hover table-bordered">

      <thead class="bg-light">

        <tr>

          <th>#</th>

          <th>Predicted At</th>

          <th>Machine</th>

          <th>Sensor</th>

          <th>Probability</th>

          <th>Status</th>

          <th>Actions</th>

        </tr>

      </thead>

      <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $predictions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prediction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

          <td><?php echo e($prediction->id); ?></td>

          <td><?php echo e(optional($prediction->predicted_at)->format('Y-m-d H:i')); ?></td>

          <td><?php echo e(optional($prediction->machine)->name); ?></td>

          <td><?php echo e(optional($prediction->sensor)->device_id); ?></td>

          <td><?php echo e($prediction->probability); ?></td>

          <td><?php echo e($prediction->status); ?></td>

          <td class="d-flex gap-2">

            <a class="btn btn-sm btn-outline-primary btn-action" href="<?php echo e(route('admin.predictions.show', $prediction)); ?>"><i class="fas fa-eye"></i></a>

            <a class="btn btn-sm btn-outline-warning btn-action" href="<?php echo e(route('admin.predictions.edit', $prediction)); ?>"><i class="fas fa-edit"></i></a>

            <form action="<?php echo e(route('admin.predictions.destroy', $prediction)); ?>" method="POST" onsubmit="return confirm('Delete this prediction?');">

              <?php echo csrf_field(); ?>

              <?php echo method_field('DELETE'); ?>

              <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>

            </form>

          </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr><td colspan="7" class="text-center">No predictions found.</td></tr>

        <?php endif; ?>

      </tbody>

    </table>

  </div>



  <div class="mt-3">

    <?php echo e($predictions->links()); ?>


  </div>

</div>

</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/predictions/index.blade.php ENDPATH**/ ?>