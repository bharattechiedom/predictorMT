<?php
$page_title = "Edit Maintenance Task";
?>
<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="wrapper active">
    <div class="page-content">
        <div class="page-container p-3">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Edit Maintenance Task #<?php echo e($task->id); ?></h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('user.maintenance-tasks.update', $task)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="machine_id" class="form-label">Machine <span class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['machine_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="machine_id" name="machine_id" required>
                                    <option value="">Select Machine</option>
                                    <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($machine->id); ?>" 
                                        <?php echo e((old('machine_id', $task->machine_id) == $machine->id) ? 'selected' : ''); ?>>
                                        <?php echo e($machine->name); ?> (<?php echo e($machine->machine_type); ?>)
                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['machine_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="assigned_to" class="form-label">Assign To</label>
                                <select class="form-select <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="assigned_to" name="assigned_to">
                                    <option value="">Select Technician</option>
                                    <?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tech->id); ?>" 
                                        <?php echo e((old('assigned_to', $task->assigned_to) == $tech->id) ? 'selected' : ''); ?>>
                                        <?php echo e($tech->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="scheduled_at" class="form-label">Schedule Date <span class="text-danger">*</span></label>
                                <input type="datetime-local" 
                                       class="form-control <?php $__errorArgs = ['scheduled_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="scheduled_at" 
                                       name="scheduled_at" 
                                       value="<?php echo e(old('scheduled_at', $task->scheduled_at->format('Y-m-d\TH:i'))); ?>" 
                                       required>
                                <?php $__errorArgs = ['scheduled_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="status" name="status">
                                    <option value="scheduled" <?php echo e(old('status', $task->status) == 'scheduled' ? 'selected' : ''); ?>>
                                        Scheduled
                                    </option>
                                    <option value="in_progress" <?php echo e(old('status', $task->status) == 'in_progress' ? 'selected' : ''); ?>>
                                        In Progress
                                    </option>
                                    <option value="completed" <?php echo e(old('status', $task->status) == 'completed' ? 'selected' : ''); ?>>
                                        Completed
                                    </option>
                                    <option value="cancelled" <?php echo e(old('status', $task->status) == 'cancelled' ? 'selected' : ''); ?>>
                                        Cancelled
                                    </option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="completed_at" class="form-label">Completion Date</label>
                                <input type="datetime-local" 
                                       class="form-control <?php $__errorArgs = ['completed_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="completed_at" 
                                       name="completed_at" 
                                       value="<?php echo e(old('completed_at', $task->completed_at ? $task->completed_at->format('Y-m-d\TH:i') : '')); ?>">
                                <?php $__errorArgs = ['completed_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="cost_estimate" class="form-label">Cost Estimate ($)</label>
                                <input type="number" 
                                       class="form-control <?php $__errorArgs = ['cost_estimate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="cost_estimate" 
                                       name="cost_estimate" 
                                       value="<?php echo e(old('cost_estimate', $task->cost_estimate)); ?>" 
                                       step="0.01" 
                                       min="0">
                                <?php $__errorArgs = ['cost_estimate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="notes" 
                                          name="notes" 
                                          rows="4"><?php echo e(old('notes', $task->notes)); ?></textarea>
                                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-12">
                                <label for="parts_required" class="form-label">Parts Required</label>
                                <div class="parts-container" id="partsContainer">
                                    <?php
                                        $parts = old('parts', json_decode($task->parts_required, true)) ?? [];
                                    ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="row g-2 mb-2 part-row">
                                        <div class="col-5">
                                            <input type="text" 
                                                   class="form-control" 
                                                   name="parts[<?php echo e($index); ?>][name]" 
                                                   placeholder="Part Name"
                                                   value="<?php echo e($part['name'] ?? ''); ?>">
                                        </div>
                                        <div class="col-3">
                                            <input type="number" 
                                                   class="form-control" 
                                                   name="parts[<?php echo e($index); ?>][quantity]" 
                                                   placeholder="Qty" 
                                                   min="1"
                                                   value="<?php echo e($part['quantity'] ?? ''); ?>">
                                        </div>
                                        <div class="col-3">
                                            <input type="number" 
                                                   class="form-control" 
                                                   name="parts[<?php echo e($index); ?>][cost]" 
                                                   placeholder="Cost" 
                                                   step="0.01" 
                                                   min="0"
                                                   value="<?php echo e($part['cost'] ?? ''); ?>">
                                        </div>
                                        <div class="col-1">
                                            <button type="button" 
                                                    class="btn btn-danger remove-part" 
                                                    <?php echo e(count($parts) === 1 ? 'disabled' : ''); ?>>
                                                <i class="bi bi-dash"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="row g-2 mb-2 part-row">
                                        <div class="col-5">
                                            <input type="text" class="form-control" name="parts[0][name]" placeholder="Part Name">
                                        </div>
                                        <div class="col-3">
                                            <input type="number" class="form-control" name="parts[0][quantity]" placeholder="Qty" min="1">
                                        </div>
                                        <div class="col-3">
                                            <input type="number" class="form-control" name="parts[0][cost]" placeholder="Cost" step="0.01" min="0">
                                        </div>
                                        <div class="col-1">
                                            <button type="button" class="btn btn-danger remove-part" disabled>
                                                <i class="bi bi-dash"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <button type="button" class="btn btn-sm btn-secondary mt-2" id="addPart">
                                    <i class="bi bi-plus"></i> Add Part
                                </button>
                            </div>

                            <div class="col-12 mt-4">
                                <div class="d-flex justify-content-end gap-2">
                                    <a href="<?php echo e(route('user.maintenance-tasks.index')); ?>" class="btn btn-secondary">Cancel</a>
                                    <button type="submit" class="btn btn-primary">Update Task</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let partIndex = <?php echo e(count($parts ?? [1])); ?>;
    const container = document.getElementById('partsContainer');
    const addButton = document.getElementById('addPart');

    addButton.addEventListener('click', function() {
        const newRow = document.createElement('div');
        newRow.className = 'row g-2 mb-2 part-row';
        newRow.innerHTML = `
            <div class="col-5">
                <input type="text" class="form-control" name="parts[${partIndex}][name]" placeholder="Part Name">
            </div>
            <div class="col-3">
                <input type="number" class="form-control" name="parts[${partIndex}][quantity]" placeholder="Qty" min="1">
            </div>
            <div class="col-3">
                <input type="number" class="form-control" name="parts[${partIndex}][cost]" placeholder="Cost" step="0.01" min="0">
            </div>
            <div class="col-1">
                <button type="button" class="btn btn-danger remove-part">
                    <i class="bi bi-dash"></i>
                </button>
            </div>
        `;
        container.appendChild(newRow);
        partIndex++;

        // Enable remove button for first row if there's more than one row
        if (container.children.length > 1) {
            container.querySelector('.remove-part[disabled]')?.removeAttribute('disabled');
        }
    });

    container.addEventListener('click', function(e) {
        if (e.target.closest('.remove-part')) {
            const row = e.target.closest('.part-row');
            row.remove();

            // If only one row remains, disable its remove button
            if (container.children.length === 1) {
                container.querySelector('.remove-part').setAttribute('disabled', true);
            }
        }
    });

    // Show/hide completion date based on status
    const statusSelect = document.getElementById('status');
    const completedAtInput = document.getElementById('completed_at');
    const completedAtParent = completedAtInput.closest('.col-md-6');

    function toggleCompletionDate() {
        if (statusSelect.value === 'completed') {
            completedAtParent.style.display = 'block';
            completedAtInput.setAttribute('required', true);
        } else {
            completedAtParent.style.display = 'none';
            completedAtInput.removeAttribute('required');
        }
    }

    statusSelect.addEventListener('change', toggleCompletionDate);
    toggleCompletionDate(); // Run on page load
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\predictormt\resources\views/user/maintenance-tasks/edit.blade.php ENDPATH**/ ?>