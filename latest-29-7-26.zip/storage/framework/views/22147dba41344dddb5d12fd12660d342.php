<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">
                          Add Alert
                        </span>

                        <div class="navbar-nav ms-auto ">
                          
        
      
    <a href="<?php echo e(route('admin.alerts.index')); ?>" class="btn themeBtn">Back</a>


                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">

<div class="container py-4">

  <div class="d-flex justify-content-between align-items-center mb-3">

    <h3 class="mb-0"></h3>


  </div>



  <?php if($errors->any()): ?>

    <div class="alert alert-danger">

      <ul class="mb-0">

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>

  <?php endif; ?>



  <form method="POST" action="<?php echo e(route('admin.alerts.store')); ?>" class="bg-white p-3 border rounded">

    <?php echo csrf_field(); ?>

    <div class="row g-3">

      <div class="col-md-6">

        <label class="form-label">Company</label>

        <select name="company_id" class="form-select" required>

          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Machine</label>

        <select name="machine_id" class="form-select" required>

          <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($machine->id); ?>"><?php echo e($machine->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Sensor (optional)</label>

        <select name="sensor_id" class="form-select">

          <option value="">None</option>

          <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($sensor->id); ?>"><?php echo e($sensor->device_id); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Level</label>

        <select name="level" class="form-select" required>

          <?php $__currentLoopData = ['info','warning','critical']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($level); ?>"><?php echo e($level); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-12">

        <label class="form-label">Message</label>

        <input type="text" name="message" class="form-control" maxlength="500" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Origin</label>

        <select name="origin" class="form-select" required>

          <?php $__currentLoopData = ['rule','prediction','manual','sensor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $origin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($origin); ?>"><?php echo e($origin); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-12">

        <label class="form-label">Payload (JSON)</label>

        <textarea name="payload" class="form-control" rows="3" placeholder='{"threshold":90}'></textarea>

      </div>

      <div class="col-md-6">

        <label class="form-label">Acknowledged By</label>

        <select name="acknowledged_by" class="form-select">

          <option value="">None</option>

          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Acknowledged At</label>

        <input type="datetime-local" name="acknowledged_at" class="form-control">

      </div>

    </div>

    <div class="mt-3">

      <button type="submit" class="btn btn-primary">Create</button>

    </div>

  </form>

</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/resources/views/admin/alerts/create.blade.php ENDPATH**/ ?>