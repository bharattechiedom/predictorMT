<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

<nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">

                            <i class="fas fa-building me-2"></i>

                            Machines

                        </span>

                        <div class="navbar-nav ms-auto">

                            <a href="<?php echo e(route('admin.machines.create')); ?>" class="btn themeBtn">Add Machine</a>

                        </div>

                    </div>

                </nav>


<div class="main-content">

<div class="card table-card bg-white p-3">


  <?php if(session('success')): ?>

    <div class="alert alert-success"><?php echo e(session('success')); ?></div>

  <?php endif; ?>



  <div class="table-responsive bg-white p-2">

    <table class="table table-hover table-bordered">

      <thead class="bg-light">

        <tr>

          <th>#</th>

          <th>Name</th>

          <th>Company</th>

          <th>Type</th>

          <th>Serial</th>

          <th>Status</th>

          <th>Actions</th>

        </tr>

      </thead>

      <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

          <td><?php echo e($machine->id); ?></td>

          <td><?php echo e($machine->name); ?></td>

          <td><?php echo e(optional($machine->company)->name); ?></td>

          <td><?php echo e($machine->machine_type); ?></td>

          <td><?php echo e($machine->serial_number); ?></td>

          <td><?php echo e($machine->status); ?></td>

          <td class="d-flex gap-2">

            <a class="btn btn-sm btn-outline-primary btn-action" href="<?php echo e(route('admin.machines.show', $machine)); ?>"><i class="fas fa-eye"></i></a>

            <a class="btn btn-sm btn-outline-warning btn-action" href="<?php echo e(route('admin.machines.edit', $machine)); ?>"><i class="fas fa-edit"></i></a>

            <form action="<?php echo e(route('admin.machines.destroy', $machine)); ?>" method="POST" onsubmit="return confirm('Delete this machine?');">

              <?php echo csrf_field(); ?>

              <?php echo method_field('DELETE'); ?>

              <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>

            </form>

          </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr><td colspan="7" class="text-center">No machines found.</td></tr>

        <?php endif; ?>

      </tbody>

    </table>

  </div>



  <div class="mt-3">

    <?php echo e($machines->links()); ?>


  </div>

</div>

</div>


<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/machines/index.blade.php ENDPATH**/ ?>