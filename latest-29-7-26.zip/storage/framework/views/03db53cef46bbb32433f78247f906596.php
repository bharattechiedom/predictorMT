<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

            <nav class="navbar navbar-expand-lg navbar-custom">

                <div class="container-fluid">

                    <span class="navbar-brand mb-0 h1">Edit Company</span>

                </div>

            </nav>



            <div class="main-content p-4">

                    <div class="card bg-white p-3 border-0">

                    <div class="card-body">



                        <?php if($errors->any()): ?>

                            <div class="alert alert-danger">

                                <ul class="mb-0">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>

                            </div>

                        <?php endif; ?>



                        <form action="<?php echo e(route('admin.companies.update', $company)); ?>" method="POST">

                            <?php echo csrf_field(); ?>

                            <?php echo method_field('PUT'); ?>



                            <div class="mb-3">

                                <label class="form-label">Name</label>

                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $company->name)); ?>" required>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Country</label>

                                <input type="text" name="country" class="form-control" value="<?php echo e(old('country', $company->country)); ?>">

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Timezone</label>

                                <input type="text" name="timezone" class="form-control" value="<?php echo e(old('timezone', $company->timezone)); ?>">

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Plan</label>

                                <select name="plan_id" class="form-select">

                                    <option value="">-- None --</option>

                                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($plan->id); ?>" <?php if($company->plan_id == $plan->id): ?> selected <?php endif; ?>><?php echo e($plan->name); ?> (<?php echo e($plan->machines_included); ?> machines)</option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                            </div>



                            <div class="mt-3">

                                <button class="btn btn-primary">Update Company</button>

                                <a href="<?php echo e(route('admin.companies.index')); ?>" class="btn btn-secondary">Cancel</a>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/resources/views/admin/companies/edit.blade.php ENDPATH**/ ?>