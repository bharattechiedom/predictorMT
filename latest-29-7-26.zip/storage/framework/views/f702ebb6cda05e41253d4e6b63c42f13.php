<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
  #plans {
    padding: 30px 0 80px;
    text-align: center;
  }

  #plans h2 {
    font-size: 30px;
    font-weight: 600;
    color: #51ade5;
    margin-bottom: 10px;
    font-family: 'Poppins', sans-serif;
    text-transform: capitalize;
  }

  #plans p.subtitle {
    color: #666;
    font-size: 16px;
    margin-bottom: 40px;
  }

</style>

<div class="condition-div">

  <div class="custom-breadcrumb mt-0">
    <span class="home-icon"><i class="fa-solid fa-house"></i></span>
    <a href="<?php echo e(route('home')); ?>">Home</a>
    <span class="arrow">›</span>
    <a href="#">Pricing Plan</a>
    <span class="arrow">›</span>
  </div>

  <section id="plans">
    <div class="container">
      <h2>Purchase a Subscription</h2>
      <p class="text-white">Choose the plan that works for you.</p>

      <div class="row justify-content-center">
        <?php if(isset($plans) && $plans->count()): ?>
        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 mb-4">
          <div class="plan-card">
            <h4><?php echo e($plan->name); ?></h4>
            <h2><?php echo e(config('app.currency', 'CAD')); ?> <?php echo e(number_format($plan->price, 2)); ?></h2>
            <span><?php echo e($plan->billing_interval ?? ''); ?></span>
            <?php if($plan->description): ?>
            <p class="text-muted mt-2"><?php echo e($plan->description); ?></p>
            <?php endif; ?>
            <ul>
              <?php if(!empty($plan->features) && is_array($plan->features)): ?>
              <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($feature); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <li>Access to member dashboard</li>
              <?php endif; ?>
            </ul>
            <?php if(auth()->check()): ?>
            <a href="<?php echo e(route('checkout.show', $plan)); ?>" class="btn btn-primary">Choose Plan</a>
            <?php else: ?>
            <a href="<?php echo e(route('signup', ['plan' => $plan->id])); ?>" class="btn btn-primary">Sign Up to Choose</a>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="col-12 text-center">
          <p class="text-white">No subscription plans are available right now. Please check back later.</p>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </section>
  </div>

</div>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/predictormt/public_html/UAT/resources/views/product.blade.php ENDPATH**/ ?>