</div>

</div>

  

  <!-- Logout Form -->

  <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">

        <?php echo csrf_field(); ?>

    </form>


    <script src="<?php echo e(asset('public/assets/js/bootstrap.bundle.min.js')); ?>"></script>

</body>

</html>

<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/include/footer.blade.php ENDPATH**/ ?>