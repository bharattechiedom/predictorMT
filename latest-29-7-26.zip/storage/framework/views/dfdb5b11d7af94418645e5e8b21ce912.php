<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <!-- Main Content -->
            <div class="col-md-9 col-lg-10">
                <!-- Top Navigation -->
                <nav class="navbar navbar-expand-lg navbar-custom">
                    <div class="container-fluid">
                        <span class="navbar-brand mb-0 h1">
                            <i class="fas fa-tags me-2"></i>
                            Plans Management
                        </span>
                        <div class="navbar-nav ms-auto">
                            <a href="<?php echo e(route('admin.plans.create')); ?>" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Add Plan
                            </a>
                        </div>
                    </div>
                </nav>

                <div class="main-content">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Plans Table -->
                    <div class="card table-card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-tags me-2"></i>
                                Plans List
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                            <th>Machines Included</th>
                                            <th>Companies</th>
                                            <th>Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($plan->id); ?></td>
                                            <td>
                                                <strong><?php echo e($plan->name); ?></strong>
                                            </td>
                                            <td>
                                                <span class="badge bg-success">$<?php echo e(number_format($plan->price, 2)); ?></span>
                                            </td>
                                            <td><?php echo e($plan->machines_included); ?></td>
                                            <td>
                                                <span class="badge bg-info"><?php echo e($plan->companies->count()); ?></span>
                                            </td>
                                            <td><?php echo e($plan->created_at->format('M d, Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.plans.show', $plan)); ?>" 
                                                   class="btn btn-sm btn-outline-primary btn-action" 
                                                   title="View">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('admin.plans.edit', $plan)); ?>" 
                                                   class="btn btn-sm btn-outline-warning btn-action" 
                                                   title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.plans.destroy', $plan)); ?>" 
                                                      method="POST" 
                                                      style="display: inline;"
                                                      onsubmit="return confirm('Are you sure you want to delete this plan?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" 
                                                            class="btn btn-sm btn-outline-danger btn-action" 
                                                            title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-4">
                                                <i class="fas fa-tags fa-3x text-muted mb-3"></i>
                                                <p class="text-muted">No plans found. <a href="<?php echo e(route('admin.plans.create')); ?>">Create the first one</a></p>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="mt-3">
                        <?php echo e($plans->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\predictormt\resources\views/admin/plans/index.blade.php ENDPATH**/ ?>