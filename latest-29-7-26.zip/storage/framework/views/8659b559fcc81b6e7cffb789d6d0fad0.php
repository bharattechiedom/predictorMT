<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">
Add Sensor Reading
                        </span>

                        <div class="navbar-nav ms-auto ">
                                <a href="<?php echo e(route('admin.sensor-readings.edit', $reading)); ?>" class="btn btn-primary">Edit</a>

          <a href="<?php echo e(route('admin.sensor-readings.index')); ?>" class="btn themeBtn">Back</a>

                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">




  <?php if($errors->any()): ?>

    <div class="alert alert-danger">

      <ul class="mb-0">

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>

  <?php endif; ?>



  <form method="POST" action="<?php echo e(route('admin.sensor-readings.store')); ?>" class="bg-white p-3 border-0 rounded">

    <?php echo csrf_field(); ?>

    <div class="row g-3">

      <div class="col-md-6">

        <label class="form-label">Sensor</label>

        <select name="sensor_id" class="form-select" required>

          <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($sensor->id); ?>"><?php echo e($sensor->device_id); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Machine</label>

        <select name="machine_id" class="form-select" required>

          <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($machine->id); ?>"><?php echo e($machine->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Timestamp</label>

        <input type="datetime-local" name="timestamp" class="form-control" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Value (float)</label>

        <input type="number" step="any" name="value_float" class="form-control">

      </div>

      <div class="col-12">

        <label class="form-label">Payload (JSON)</label>

        <textarea name="payload" class="form-control" rows="4" placeholder='{"key":"value"}'></textarea>

      </div>

    </div>

    <div class="mt-3">

      <button type="submit" class="btn btn-primary">Create</button>

    </div>

  </form>

</div>
</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/sensor-readings/create.blade.php ENDPATH**/ ?>