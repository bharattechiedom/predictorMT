<?php

$page_title = "Maintenance";

?>

 <?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<body>

  <div class="wrapper active">

    <div class="page-content">

        <div class="page-container p-3">

            <div class="card bg-white">

                <div class="card-header d-flex justify-content-between align-items-center">

                    <div>

                        <h4 class="mb-0">Maintenance Tasks</h4>

                        <nav aria-label="breadcrumb" class="mt-2">

                            <ol class="breadcrumb p-0">

                                <li class="breadcrumb-item"><a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>

                                <li class="breadcrumb-item active" aria-current="page">Maintenance</li>

                            </ol>

                        </nav>

                    </div>

                    <div class="d-flex gap-2">

                        <div class="search-box position-relative w-auto">

                            <input type="text" class="form-control pe-5" id="maintenanceSearch" placeholder="Search Maintenance...">

                            <span class="position-absolute top-50 end-0 translate-middle-y pe-3" style="color: #ccc;">

                                <i class="bi bi-search"></i>

                            </span>

                        </div>

                        <a href="<?php echo e(route('user.maintenance-tasks.create')); ?>" class="btn btn-primary">

                            <i class="bi bi-plus"></i> New Task

                        </a>

                    </div>

                </div>



                <div class="card-body">

                    <?php if(session('success')): ?>

                    <div class="alert alert-success alert-dismissible fade show" role="alert">

                        <?php echo e(session('success')); ?>


                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>

                    </div>

                    <?php endif; ?>



                    <!-- Filters -->

                    <div class="row g-3 mb-4">

                        <div class="col-md-3">

                            <select class="form-select" id="statusFilter">

                                <option value="">All Status</option>

                                <option value="scheduled">Scheduled</option>

                                <option value="in_progress">In Progress</option>

                                <option value="completed">Completed</option>

                                <option value="cancelled">Cancelled</option>

                            </select>

                        </div>

                        <div class="col-md-3">

                            <select class="form-select" id="machineFilter">

                                <option value="">All Machines</option>

                                <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($machine->id); ?>"><?php echo e($machine->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>

                        <div class="col-md-3">

                            <input type="date" class="form-control" id="dateFilter">

                        </div>

                    </div>



                    <!-- Tasks Table -->

                    <div class="table-responsive">

                        <table class="table table-hover">

                            <thead>

                                <tr>

                                    <th>#</th>

                                    <th>Machine</th>

                                    <th>Scheduled</th>

                                    <th>Status</th>

                                    <th>Assigned To</th>

                                    <th>Cost</th>

                                    <th class="text-center" width="100">Actions</th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <tr>

                                    <td><?php echo e($task->id); ?></td>

                                    <td><?php echo e($task->machine->name); ?></td>

                                    <td>

                                        <?php echo e($task->scheduled_at->format('M d, Y H:i')); ?>


                                        <br>

                                        <small class="text-muted">

                                            (<?php echo e($task->scheduled_at->diffForHumans()); ?>)

                                        </small>

                                    </td>

                                    <td>

                                        <?php

                                            $statusClass = [

                                                'scheduled' => 'primary',

                                                'in_progress' => 'warning',

                                                'completed' => 'success',

                                                'cancelled' => 'danger'

                                            ][$task->status];

                                        ?>

                                        <span class="badge bg-<?php echo e($statusClass); ?>">

                                            <?php echo e(ucfirst(str_replace('_', ' ', $task->status))); ?>


                                        </span>

                                    </td>

                                    <td>

                                        <?php if($task->assigned_to): ?>

                                            <?php echo e($task->assignedTo->name); ?>


                                        <?php else: ?>

                                            <span class="text-muted">Unassigned</span>

                                        <?php endif; ?>

                                    </td>

                                    <td>

                                        <?php if($task->cost_estimate): ?>

                                            $<?php echo e(number_format($task->cost_estimate, 2)); ?>


                                        <?php else: ?>

                                            -

                                        <?php endif; ?>

                                    </td>

                                    <td class="text-center">

                                        <div class="btn-group gap-1 table-td-Btn">

                                            <a href="<?php echo e(route('user.maintenance-tasks.show', $task)); ?>" 

                                               class="btn btn-sm btn-outline-info"

                                               title="View Details">

                                                <i class="bi bi-eye"></i>

                                            </a>

                                            <a href="<?php echo e(route('user.maintenance-tasks.edit', $task)); ?>" 

                                               class="btn btn-sm btn-outline-info  "

                                               title="Edit Task">

                                                <i class="bi bi-pencil"></i>

                                            </a>

                                            <form action="<?php echo e(route('user.maintenance-tasks.destroy', $task)); ?>" 

                                                  method="POST" 

                                                  onsubmit="return confirm('Are you sure you want to delete this task?');"

                                                  style="display: inline;">

                                                <?php echo csrf_field(); ?>

                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" 

                                                        class="btn btn-sm btn-outline-info"

                                                        title="Delete Task">

                                                    <i class="bi bi-trash"></i>

                                                </button>

                                            </form>

                                        </div>

                                    </td>

                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <tr>

                                    <td colspan="7" class="text-center">No maintenance tasks found</td>

                                </tr>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>



                    <div class="mt-3">

                        <?php echo e($tasks->links()); ?>


                    </div>

                </div>

            </div>

        </div>

    </div>

</div>



<script>
(function() {
    'use strict';
    
    const searchInput = document.getElementById('maintenanceSearch');
    const table = document.querySelector('.table tbody');
    
    if (searchInput && table) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            const rows = table.querySelectorAll('tr');
            let visibleCount = 0;
            
            rows.forEach(function(row) {
                // Skip empty state row
                if (row.querySelector('td[colspan]')) {
                    return;
                }
                
                const text = row.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
    
    // Handle filter changes
    const statusFilter = document.getElementById('statusFilter');
    const machineFilter = document.getElementById('machineFilter');
    const dateFilter = document.getElementById('dateFilter');
    
    function applyFilters() {
        const status = statusFilter.value;
        const machine = machineFilter.value;
        const date = dateFilter.value;
        
        const url = new URL(window.location.href);
        url.searchParams.set('status', status);
        url.searchParams.set('machine_id', machine);
        url.searchParams.set('date', date);
        
        window.location.href = url.toString();
    }
    
    if (statusFilter) statusFilter.addEventListener('change', applyFilters);
    if (machineFilter) machineFilter.addEventListener('change', applyFilters);
    if (dateFilter) dateFilter.addEventListener('change', applyFilters);
})();
</script>



        </div> <!-- /row -->

      </div> <!-- /page-container -->

    </div> <!-- /page-content -->

  </div> <!-- /wrapper -->



 

</body>



<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/resources/views/user/maintenance-tasks/index.blade.php ENDPATH**/ ?>