<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">
                         Add Subscription
                        </span>

                        <div class="navbar-nav ms-auto ">
                          
    <a href="<?php echo e(route('admin.subscriptions.index')); ?>" class="btn themeBtn">Back</a>


                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">

  <?php if($errors->any()): ?>

    <div class="alert alert-danger">

      <ul class="mb-0">

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>

  <?php endif; ?>



  <form method="POST" action="<?php echo e(route('admin.subscriptions.store')); ?>" class="bg-white p-3 border-0 rounded">

    <?php echo csrf_field(); ?>

    <div class="row g-3">

      <div class="col-md-6">

        <label class="form-label">Company</label>

        <select name="company_id" class="form-select" required>

          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Plan</label>

        <select name="plan_id" class="form-select" required>

          <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Status</label>

        <select name="status" class="form-select" required>

          <?php $__currentLoopData = ['active','trialing','past_due','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Started At</label>

        <input type="datetime-local" name="started_at" class="form-control" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Ended At</label>

        <input type="datetime-local" name="ended_at" class="form-control">

      </div>

      <div class="col-md-6">

        <label class="form-label">External Subscription ID</label>

        <input type="text" name="external_subscription_id" class="form-control">

      </div>

    </div>

    <div class="mt-3">

      <button type="submit" class="btn btn-primary">Create</button>

    </div>

  </form>

</div>

</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/subscriptions/create.blade.php ENDPATH**/ ?>