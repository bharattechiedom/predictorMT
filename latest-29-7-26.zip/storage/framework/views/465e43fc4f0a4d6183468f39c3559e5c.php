<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-5 text-center">
    <h2>✅ Payment Successful</h2>
    <p>
        Amount Paid: <?php echo e(strtoupper($payment->currency)); ?>

        <?php echo e(number_format($payment->amount, 2)); ?>

    </p>

    <a href="<?php echo e(route('signup')); ?>" class="btn btn-primary">
        Continue to Registration
    </a>
</div>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp\htdocs\predictormt\resources\views/checkout/success.blade.php ENDPATH**/ ?>