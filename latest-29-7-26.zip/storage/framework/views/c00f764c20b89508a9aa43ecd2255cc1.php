<?php

$page_title = "Create Record";

?>



<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="page-content p-3 bg-white">

  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center py-2">

    <h4 class="header-title mb-0 text-white">Add New Record</h4>

    <a href="<?php echo e(route('user.machines.index')); ?>" class="btn btn-secondary">← Back to List</a>

  </div>
  



  <div class="card-body bg-white">

  <?php if($errors->any()): ?>

    <div class="alert alert-danger">

      <ul class="mb-0">

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>

  <?php endif; ?>

  <form method="POST" action="<?php echo e(route('user.machines.store')); ?>" class="bg-white p-3">

    <?php echo csrf_field(); ?>

    <div class="row g-3">

      

      <div class="col-md-6">

        <label class="form-label">Name <span>* </span></label>

        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Type <span>* </span></label>

        <input type="text" name="machine_type" class="form-control" value="<?php echo e(old('machine_type')); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Serial Number <span>* </span></label>

        <input type="text" name="serial_number" class="form-control" value="<?php echo e(old('serial_number')); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Location <span>* </span></label>

        <input type="text" name="location" class="form-control" value="<?php echo e(old('location')); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Installed At <span>* </span></label>

        <input type="date" name="installed_at" class="form-control" value="<?php echo e(old('installed_at')); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Status <span>* </span></label>

        <select name="status" class="form-select" required>

          <option value="healthy" <?php echo e(old('status')=='healthy'?'selected':''); ?>>healthy</option>

          <option value="at_risk" <?php echo e(old('status')=='at_risk'?'selected':''); ?>>at_risk</option>

          <option value="critical" <?php echo e(old('status')=='critical'?'selected':''); ?>>critical</option>

          <option value="offline" <?php echo e(old('status')=='offline'?'selected':''); ?>>offline</option>

        </select>

      </div>

    </div>



    <div class="mt-3">

      <button type="submit" class="lab-btn">Create</button>

    </div>

  </form>

  </div>

</div>
</div>

<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/predictormt/public_html/resources/views/user/machines/create.blade.php ENDPATH**/ ?>