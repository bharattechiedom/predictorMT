<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">

            <nav class="navbar navbar-expand-lg navbar-custom">

                <div class="container-fluid">

                    <span class="navbar-brand mb-0 h1">Edit User</span>

                </div>

            </nav>



            <div class="main-content p-4">

                    <div class="card bg-white p-3 border-0">

                    <div class="card-body">



                        <?php if($errors->any()): ?>

                            <div class="alert alert-danger">

                                <ul class="mb-0">

                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li><?php echo e($error); ?></li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>

                            </div>

                        <?php endif; ?>



                        <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST">

                            <?php echo csrf_field(); ?>

                            <?php echo method_field('PUT'); ?>



                            <div class="mb-3">

                                <label class="form-label">Company</label>

                                <select name="company_id" class="form-select">

                                    <option value="">-- None --</option>

                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($company->id); ?>" <?php if($user->company_id == $company->id): ?> selected <?php endif; ?>><?php echo e($company->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Name</label>

                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Email</label>

                                <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>" required>

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Password (leave blank to keep current)</label>

                                <input type="password" name="password" class="form-control">

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Phone</label>

                                <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $user->phone)); ?>">

                            </div>



                            <div class="mb-3">

                                <label class="form-label">Role</label>

                                <select name="role" class="form-select" required>

                                    <?php

                                        $roles = ['superadmin','admin','manager','technician','viewer'];

                                    ?>

                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($r); ?>" <?php if($user->role == $r): ?> selected <?php endif; ?>><?php echo e(ucfirst($r)); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>

                            </div>



                            <div class="mt-3">

                                <button class="btn btn-primary">Update User</button>

                                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">Cancel</a>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>