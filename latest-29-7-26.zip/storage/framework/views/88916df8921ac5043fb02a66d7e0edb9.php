<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-5">
    <div class="card p-4">
        <h3><?php echo e($plan->name); ?></h3>
        <p><?php echo e($plan->billing_interval); ?></p>
        <h4><?php echo e(config('app.currency','CAD')); ?> <?php echo e(number_format($plan->price,2)); ?></h4>

        <form method="POST" action="<?php echo e(route('checkout.create_session', $plan)); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-success">Pay & Continue</button>
            <a href="<?php echo e(route('subscription')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php /**PATH D:\xampp\htdocs\predictormt\resources\views/checkout/show.blade.php ENDPATH**/ ?>