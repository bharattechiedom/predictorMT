<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





            <!-- Main Content -->

            <div class="col-md-9 col-lg-10 p-0">

                <!-- Top Navigation -->

                <nav class="navbar navbar-expand-lg navbar-custom">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1">

                            <i class="fas fa-users me-2"></i>

                            Users Management

                        </span>

                        <div class="navbar-nav ms-auto">

                            <a href="<?php echo e(route('admin.users.create')); ?>" class="btn themeBtn">

                                <i class="fas fa-plus me-2"></i>Add User

                            </a>

                        </div>

                    </div>

                </nav>



                <div class="main-content">

                    <?php if(session('success')): ?>

                        <div class="alert alert-success alert-dismissible fade show" role="alert">

                            <i class="fas fa-check-circle me-2"></i>

                            <?php echo e(session('success')); ?>


                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>

                        </div>

                    <?php endif; ?>



                    <!-- Users Table -->

                    <div class="card table-card bg-white p-3">

                        <div class="card-header bg-transparent theme-heading-color border-0">

                            <h5 class="mb-0">

                                <i class="fas fa-users me-2"></i>

                                Users List

                            </h5>

                        </div>

                        <div class="card-body">

                            <div class="table-responsive">

                                <table class="table table-hover">

                                    <thead>

                                        <tr>

                                            <th>ID</th>

                                            <th>Name</th>

                                            <th>Email</th>

                                            <th>Role</th>

                                            <th>Company</th>

                                            <th>Phone</th>

                                            <th>Created</th>

                                            <th>Actions</th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                        <tr>

                                            <td><?php echo e($user->id); ?></td>

                                            <td>

                                                <strong><?php echo e($user->name); ?></strong>

                                            </td>

                                            <td><?php echo e($user->email); ?></td>

                                            <td>

                                                <?php

                                                    $roleColors = [

                                                        'superadmin' => 'danger',

                                                        'admin' => 'warning',

                                                        'manager' => 'info',

                                                        'technician' => 'primary',

                                                        'viewer' => 'secondary'

                                                    ];

                                                ?>

                                                <span class="badge bg-<?php echo e($roleColors[$user->role] ?? 'secondary'); ?>">

                                                    <?php echo e(ucfirst($user->role)); ?>


                                                </span>

                                            </td>

                                            <td>

                                                <?php if($user->company): ?>

                                                    <span class="badge bg-info"><?php echo e($user->company->name); ?></span>

                                                <?php else: ?>

                                                    <span class="badge bg-secondary">No Company</span>

                                                <?php endif; ?>

                                            </td>

                                            <td><?php echo e($user->phone ?? 'N/A'); ?></td>

                                            <td><?php echo e($user->created_at->format('M d, Y')); ?></td>

                                            <td>

                                                <a href="<?php echo e(route('admin.users.show', $user)); ?>" 

                                                   class="btn btn-sm btn-outline-primary btn-action" 

                                                   title="View">

                                                    <i class="fas fa-eye"></i>

                                                </a>

                                                <a href="<?php echo e(route('admin.users.edit', $user)); ?>" 

                                                   class="btn btn-sm btn-outline-warning btn-action" 

                                                   title="Edit">

                                                    <i class="fas fa-edit"></i>

                                                </a>

                                                <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" 

                                                      method="POST" 

                                                      style="display: inline;"

                                                      onsubmit="return confirm('Are you sure you want to delete this user?')">

                                                    <?php echo csrf_field(); ?>

                                                    <?php echo method_field('DELETE'); ?>

                                                    <button type="submit" 

                                                            class="btn btn-sm btn-outline-danger btn-action" 

                                                            title="Delete">

                                                        <i class="fas fa-trash"></i>

                                                    </button>

                                                </form>

                                            </td>

                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <tr>

                                            <td colspan="8" class="text-center py-4">

                                                <i class="fas fa-users fa-3x text-muted mb-3"></i>

                                                <p class="text-muted">No users found. <a href="<?php echo e(route('admin.users.create')); ?>">Create the first one</a></p>

                                            </td>

                                        </tr>

                                        <?php endif; ?>

                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                    <div class="mt-3">

                        <?php echo e($users->links()); ?>


                    </div>

                </div>

            </div>

        </div>

    </div>



    <?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home2/predictormt/public_html/resources/views/admin/users/index.blade.php ENDPATH**/ ?>