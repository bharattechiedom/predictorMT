<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">

                           Add Sensor
                        </span>

                        <div class="navbar-nav ms-auto ">
                           <a href="<?php echo e(route('admin.sensors.index')); ?>" class="btn themeBtn">Back</a>
                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">




  <?php if($errors->any()): ?>

    <div class="alert alert-danger">

      <ul class="mb-0">

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>

  <?php endif; ?>



  <form method="POST" action="<?php echo e(route('admin.sensors.store')); ?>" class="bg-white p-3 border-0 rounded">

    <?php echo csrf_field(); ?>

    <div class="row g-3">

      <div class="col-md-6">

        <label class="form-label">Device ID</label>

        <input type="text" name="device_id" class="form-control" value="<?php echo e(old('device_id')); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Sensor Type</label>

        <input type="text" name="sensor_type" class="form-control" value="<?php echo e(old('sensor_type')); ?>" required>

      </div>

      <div class="col-md-6">

        <label class="form-label">Machine</label>

        <select name="machine_id" class="form-select">

          <option value="">(Optional) Select Machine</option>

          <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($machine->id); ?>"><?php echo e($machine->name); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

      <div class="col-md-6">

        <label class="form-label">Firmware Version</label>

        <input type="text" name="firmware_version" class="form-control" value="<?php echo e(old('firmware_version')); ?>">

      </div>

      <div class="col-md-6">

        <label class="form-label">Battery Level (%)</label>

        <input type="number" name="battery_level" class="form-control" min="0" max="100" value="<?php echo e(old('battery_level')); ?>">

      </div>

      <div class="col-md-6">

        <label class="form-label">Last Seen</label>

        <input type="datetime-local" name="last_seen" class="form-control" value="<?php echo e(old('last_seen')); ?>">

      </div>

      <div class="col-md-6">

        <label class="form-label">Status</label>

        <select name="status" class="form-select" required>

          <?php $__currentLoopData = ['active','inactive','faulty','provisioning']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option value="<?php echo e($status); ?>" <?php echo e(old('status')===$status?'selected':''); ?>><?php echo e($status); ?></option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

      </div>

    </div>

    <div class="mt-3">

      <button type="submit" class="btn btn-primary">Create</button>

    </div>

  </form>

</div>

</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/sensors/create.blade.php ENDPATH**/ ?>