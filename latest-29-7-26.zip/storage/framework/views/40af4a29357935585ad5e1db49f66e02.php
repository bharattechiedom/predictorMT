<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="col-md-9 col-lg-10">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">Add Machine</h3>
    <a href="<?php echo e(route('admin.machines.index')); ?>" class="btn btn-secondary">Back</a>
  </div>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" action="<?php echo e(route('admin.machines.store')); ?>" class="bg-white p-3 border rounded">
    <?php echo csrf_field(); ?>
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Company</label>
        <select name="company_id" class="form-select" required>
          <option value="" disabled selected>Select Company</option>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Name</label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Type</label>
        <input type="text" name="machine_type" class="form-control" value="<?php echo e(old('machine_type')); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Serial Number</label>
        <input type="text" name="serial_number" class="form-control" value="<?php echo e(old('serial_number')); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Location</label>
        <input type="text" name="location" class="form-control" value="<?php echo e(old('location')); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Installed At</label>
        <input type="date" name="installed_at" class="form-control" value="<?php echo e(old('installed_at')); ?>">
      </div>
      <div class="col-md-6">
        <label class="form-label">Status</label>
        <select name="status" class="form-select" required>
          <option value="healthy" <?php echo e(old('status')=='healthy'?'selected':''); ?>>healthy</option>
          <option value="at_risk" <?php echo e(old('status')=='at_risk'?'selected':''); ?>>at_risk</option>
          <option value="critical" <?php echo e(old('status')=='critical'?'selected':''); ?>>critical</option>
          <option value="offline" <?php echo e(old('status')=='offline'?'selected':''); ?>>offline</option>
        </select>
      </div>
    </div>

    <div class="mt-3">
      <button type="submit" class="btn btn-primary">Create</button>
    </div>
  </form>
</div>

<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/machines/create.blade.php ENDPATH**/ ?>