<?php

$page_title = "List View";

?>

 <?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="page-content p-3 bg-white">

 <div class="card-header d-flex justify-content-between align-items-center mb-3">

  <h4 class="header-title mb-0">Machines</h4>

  <div class="d-flex gap-2">

    <div class="search-box position-relative w-auto">

      <input type="text" class="form-control pe-5" id="machineSearch" placeholder="Search Machines...">

      <span class="position-absolute top-50 end-0 translate-middle-y pe-3" style="color: #ccc;">

        <i class="bi bi-search"></i>

      </span>

    </div>

    <a href="<?php echo e(route('user.machines.create')); ?>" class="btn btn-dark">Add</a>

  </div>

</div>



  <div class="table-responsive">

    <table class="table table-hover table-bordered">

      <thead class="bg-light">

        <tr>

          <th>#</th>

          <th>Name</th>

          <th>Type</th>

          <th>Serial</th>

          <th>Location</th>

          <th>Status</th>

          <th class="text-center" width="100">Action</th>

        </tr>

      </thead>

      <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

          <td><?php echo e($loop->iteration + ($machines->currentPage()-1)*$machines->perPage()); ?></td>

          <td><?php echo e($machine->name); ?></td>

          <td><?php echo e($machine->machine_type); ?></td>

          <td><?php echo e($machine->serial_number); ?></td>

          <td><?php echo e($machine->location); ?></td>

          <td><span class="badge bg-success"><?php echo e($machine->status ?: 'N/A'); ?></span></td>

          <td>

            <div class="d-flex gap-2 table-td-Btn">

              <a href="<?php echo e(route('user.machines.edit', $machine)); ?>" class="btn btn-sm btn-outline-info" title="Edit">

                <i class="bi bi-pencil"></i>

              </a>

              <a href="<?php echo e(route('user.machines.show', $machine)); ?>" class="btn btn-sm btn-outline-info" title="View">

                <i class="bi bi-eye"></i>

              </a>

              <form method="POST" action="<?php echo e(route('user.machines.destroy', $machine)); ?>" onsubmit="return confirm('Delete this machine?');">

                <?php echo csrf_field(); ?>

                <?php echo method_field('DELETE'); ?>

                <button type="submit" class="btn btn-sm btn-outline-info" title="Delete">

                  <i class="bi bi-trash"></i>

                </button>

              </form>

            </div>

          </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>

          <td colspan="7" class="text-center">No machines found.</td>

        </tr>

        <?php endif; ?>

      </tbody>

    </table>

  </div>



  <div class="mt-3">

    <?php echo e($machines->links()); ?>


  </div>

</div>



<script>

(function() {

    'use strict';

    

    const searchInput = document.getElementById('machineSearch');

    const table = document.querySelector('.table tbody');

    

    if (searchInput && table) {

        searchInput.addEventListener('input', function() {

            const searchTerm = this.value.toLowerCase().trim();

            const rows = table.querySelectorAll('tr');

            

            rows.forEach(function(row) {

                if (row.querySelector('td[colspan]')) {

                    return;

                }

                

                const text = row.textContent.toLowerCase();

                row.style.display = text.includes(searchTerm) ? '' : 'none';

            });

        });

    }

})();

</script>



<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/predictormt/public_html/resources/views/user/machines/index.blade.php ENDPATH**/ ?>