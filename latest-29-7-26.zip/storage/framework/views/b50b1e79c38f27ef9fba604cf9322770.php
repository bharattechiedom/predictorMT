<!DOCTYPE html>



<html lang="en" data-sidenav-size="sm-hover-active" data-bs-theme="light" data-menu-color="light"

  data-topbar-color="brand">



<head>

  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">



  <title><?php echo isset($page_title) ? ucfirst($page_title) : 'predictorMt'; ?></title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">

  <meta content="Coderthemes" name="author">



  <!-- App favicon -->

  <link rel="shortcut icon" href="<?php echo e(asset('public/assets/images/predictorMt-Technologies.png')); ?>">
  
  <!-- Vendor css -->

  <link href="<?php echo e(asset('public/assets/css/vendor.min.css')); ?>" rel="stylesheet" type="text/css">

  <!-- App css -->

  <link href="<?php echo e(asset('public/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style">


  <!-- Icons css -->

  <link href="<?php echo e(asset('public/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">

  <link href="<?php echo e(asset('public/assets/css/custom.css')); ?>" rel="stylesheet" type="text/css">



  <!-- Theme Config Js -->

  <script src="<?php echo e(asset('public/assets/js/config.js')); ?>"></script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">



  <script type="text/javascript" src="https://cdn.canvasjs.com/canvasjs.min.js"></script>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">

  <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <!-- Bootstrap JS (required for mobile navbar toggle) -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Bootstrap Bundle (includes Popper) -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



  <!-- Optional: jQuery (agar aur JS dependency ho) -->

  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>



  <meta charset="UTF-8">

  <script src="<?php echo e(asset('assets/js/chart.js')); ?>"></script>

</head>



<body>



  <header class="header_top">

    <nav class="navbar navbar-expand-lg">

      <div class="container-fluid headr">

        <!-- Logo Left -->

        <!-- <a class="navbar-brand" href="<?php echo e(route('user.dashboard')); ?>">

          <img src="<?php echo e(asset('public/assets/images/predictorMt-logo.png')); ?>" alt="">

        </a> -->



        <!-- Toggle Button -->

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">

          <span class="navbar-toggler-icon"></span>

        </button>



        <!-- Navbar Content -->

        <div class="collapse navbar-collapse" id="navbarNavDropdown">

          <!-- Center Nav Links -->

          <?php

          $currentRoute = Request::route()->getName();

          ?>



          <ul class="navbar-nav mx-auto text-center">

            <li class="nav-item">

              <a class="nav-link <?php echo e($currentRoute == 'user.dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a>

            </li>

            <li class="nav-item">

              <a class="nav-link <?php echo e($currentRoute == 'user.machines.index' ? 'active' : ''); ?>" href="<?php echo e(route('user.machines.index')); ?>">Machines</a>

            </li>

            <li class="nav-item">

              <a class="nav-link <?php echo e($currentRoute == 'user.sensors.index' ? 'active' : ''); ?>" href="<?php echo e(route('user.sensors.index')); ?>">Sensors</a>

            </li>

            <li class="nav-item">

              <a class="nav-link <?php echo e($currentRoute == 'user.predictions.index' ? 'active' : ''); ?>" href="<?php echo e(route('user.predictions.index')); ?>">Predictions</a>

            </li>

            <li class="nav-item">

              <a class="nav-link <?php echo e($currentRoute == 'user.maintenance-tasks.index' ? 'active' : ''); ?>" href="<?php echo e(route('user.maintenance-tasks.index')); ?>">Maintenance</a>

            </li>

            <?php if(Route::has('user.alerts.index')): ?>

            <li class="nav-item">

              <a class="nav-link <?php echo e(str_contains($currentRoute, 'user.alerts') ? 'active' : ''); ?>" href="<?php echo e(route('user.alerts.index')); ?>">Alerts</a>

            </li>

            <?php endif; ?>

            <?php if(Route::has('user.reports.index')): ?>

            <li class="nav-item">

              <a class="nav-link <?php echo e(str_contains($currentRoute, 'user.reports') ? 'active' : ''); ?>" href="<?php echo e(route('user.reports.index')); ?>">Reports</a>

            </li>

            <?php endif; ?>

            <?php if(Route::has('user.billing.index')): ?>

            <li class="nav-item">

              <a class="nav-link <?php echo e(str_contains($currentRoute, 'user.billing') ? 'active' : ''); ?>" href="<?php echo e(route('user.billing.index')); ?>">Billing</a>

            </li>

            <?php endif; ?>

          </ul>

          <div class="btn_grp d-flex align-items-center gap-2">


          <div class="dropdown userDropdown-toggle">
            <button class="btn btn-secondary dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fa-regular fa-user"></i> User
            </button>

            <ul class="dropdown-menu">
              <li>
                <a class="dropdown-item" href="<?php echo e(route('user.dashboard')); ?>">
                  <i class="bi bi-speedometer2"></i> Dashboard
                </a>
              </li>
              <li>
                <a href="<?php echo e(route('user.profile')); ?>" class="dropdown-item"> 
                  <i class="fa fa-user"></i> Profile
                </a>
              </li>
              <li>
                <form method="POST" action="<?php echo e(route('user.logout')); ?>">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="dropdown-item logout">
                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                  </button>
                </form>
              </li>
            </ul>
          </div>

          <!-- <div class="dropdown">
            <button class="btn_join dropdown-toggle acc-btn"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
             
            </button>

            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <a class="dropdown-item" href="<?php echo e(route('user.dashboard')); ?>">
                  Dashboard
                </a>
              </li>
              <li>
                <form method="POST" action="<?php echo e(route('user.logout')); ?>">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="dropdown-item logout">
                    Logout
                  </button>
                </form>
              </li>
            </ul>
          </div> -->



            <!-- Profile Button -->

            <!-- <a href="<?php echo e(route('user.profile')); ?>" class="btn-custom me-2 d-flex align-items-center">

              <div class="icon-circle me-2">

                <i class="fa fa-user"></i>

              </div>

              <span>Profile</span>

            </a> -->



            <!-- Logout Button -->

            <!-- <form method="POST" action="<?php echo e(route('user.logout')); ?>" style="display: inline;">

              <?php echo csrf_field(); ?>

              <button type="submit" class="btn-custom d-flex align-items-center" style="background: none; border: none; cursor: pointer;">

                <div class="icon-circle me-2">

                  <i class="fa fa-sign-out"></i>

                </div>

                <span>Log Out</span>

              </button>

            </form> -->

          </div>





        </div>

      </div>

    </nav>

  </header>

  <!-- Begin page -->

  <div class="wrapper active">



    <!-- Menu -->

    <!-- Sidenav Menu Start -->

    <div class="sidenav-menu show">



      <!-- Brand Logo -->
        <a class="navbar-brand" href="<?php echo e(route('user.dashboard')); ?>">

          <img src="<?php echo e(asset('public/assets/user/images/footer-logo.png')); ?>" alt="">

        </a>



      <!-- Full Sidebar Menu Close Button -->

      <button class="button-close-fullsidebar">

        <i class="ri-close-line align-middle"></i>

      </button>



      <div data-simplebar="init" class="simplebar-scrollable-y">

        <div class="simplebar-wrapper active" style="margin: 0px;">

          <div class="simplebar-height-auto-observer-wrapper">

            <div class="simplebar-height-auto-observer"></div>

          </div>

          <div class="simplebar-mask show">

            <div class="simplebar-offset" style="right: 0px; bottom: 0px;">

              <div class="simplebar-content-wrapper active" tabindex="0" role="region"

                aria-label="scrollable content" style="height: 100%; overflow: hidden scroll;">

                <div class="simplebar-content show" style="padding: 0px;">



                  <!--- Sidenav Menu -->

                  <ul class="side-nav">

                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.dashboard')); ?>" class="side-nav-link <?php echo e($currentRoute == 'user.dashboard' ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-speedometer2"></i></span>

                        <span class="menu-text">Dashboard</span>

                      </a>

                    </li>



                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.machines.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'machines') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-cpu"></i></span>

                        <span class="menu-text">Machines</span>

                      </a>

                    </li>



                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.sensors.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'sensors') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-activity"></i></span>

                        <span class="menu-text">Sensors</span>

                      </a>

                    </li>



                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.predictions.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'prediction') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-graph-up-arrow"></i></span>

                        <span class="menu-text">Predictions</span>

                      </a>

                    </li>



                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.maintenance-tasks.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'maintenance') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-wrench-adjustable"></i></span>

                        <span class="menu-text">Maintenance</span>

                      </a>

                    </li>



                    <?php if(Route::has('user.alerts.index')): ?>

                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.alerts.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'user.alerts') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-exclamation-triangle"></i></span>

                        <span class="menu-text">Alert</span>

                      </a>

                    </li>

                    <?php endif; ?>



                    <?php if(Route::has('user.reports.index')): ?>

                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.reports.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'user.reports') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-bar-chart-line"></i></span>

                        <span class="menu-text">Reports</span>

                      </a>

                    </li>

                    <?php endif; ?>



                    <?php if(Route::has('user.billing.index')): ?>

                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.billing.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'user.billing') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-credit-card-2-front"></i></span>

                        <span class="menu-text">Billing</span>

                      </a>

                    </li>

                    <?php endif; ?>



                    <?php if(Route::has('user.team.index')): ?>

                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.team.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'user.team') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-people"></i></span>

                        <span class="menu-text">Team</span>

                      </a>

                    </li>

                    <?php endif; ?>



                    <?php if(Route::has('user.support.index')): ?>

                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.support.index')); ?>" class="side-nav-link <?php echo e(str_contains($currentRoute, 'user.support') ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-life-preserver"></i></span>

                        <span class="menu-text">Support</span>

                      </a>

                    </li>

                    <?php endif; ?>



                    <li class="side-nav-item">

                      <a href="<?php echo e(route('user.profile')); ?>" class="side-nav-link <?php echo e($currentRoute == 'user.profile' ? 'active' : ''); ?>">

                        <span class="menu-icon"><i class="bi bi-gear"></i></span>

                        <span class="menu-text">Settings</span>

                      </a>

                    </li>

                  </ul>

                  <div class="clearfix"></div>

                </div>

              </div>

            </div>

          </div>

          <div class="simplebar-placeholder" style="width: 240px; height: 826px;"></div>

        </div>

        <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">

          <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>

        </div>

        <div class="simplebar-track simplebar-vertical" style="visibility: visible;">

          <div class="simplebar-scrollbar"

            style="height: 527px; transform: translate3d(0px, 0px, 0px); display: block;"></div>

        </div>

      </div>

    </div>

    <!-- Sidenav Menu End -->



    <!-- Topbar Start -->



    <!-- Topbar End --><?php /**PATH D:\xampp\htdocs\predictormt\resources\views/user/include/header.blade.php ENDPATH**/ ?>