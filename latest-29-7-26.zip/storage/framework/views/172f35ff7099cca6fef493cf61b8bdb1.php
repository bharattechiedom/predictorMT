<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="col-md-9 col-lg-10 p-0">
  <nav class="navbar navbar-expand-lg navbar-custom bg-black">

                    <div class="container-fluid">

                        <span class="navbar-brand mb-0 h1 text-white">

                            <i class="fas fa-building me-2"></i>

                            Machine Details

                        </span>

                        <div class="navbar-nav ms-auto ">
                         <a href="<?php echo e(route('admin.machines.edit', $machine)); ?>" class="btn btn-primary">Edit</a>

      <a href="<?php echo e(route('admin.machines.index')); ?>" class="btn themeBtn ms-2">Back</a>
                        </div>

                    </div>

                </nav>



<div class="main-content p-4">
  <div class="card bg-white p-3 border-0">


  <?php if(session('success')): ?>

    <div class="alert alert-success"><?php echo e(session('success')); ?></div>

  <?php endif; ?>



  <div class="bg-white p-3 border rounded">

    <dl class="row mb-0">

      <dt class="col-sm-3">ID</dt><dd class="col-sm-9"><?php echo e($machine->id); ?></dd>

      <dt class="col-sm-3">Company</dt><dd class="col-sm-9"><?php echo e(optional($machine->company)->name); ?></dd>

      <dt class="col-sm-3">Name</dt><dd class="col-sm-9"><?php echo e($machine->name); ?></dd>

      <dt class="col-sm-3">Type</dt><dd class="col-sm-9"><?php echo e($machine->machine_type); ?></dd>

      <dt class="col-sm-3">Serial</dt><dd class="col-sm-9"><?php echo e($machine->serial_number); ?></dd>

      <dt class="col-sm-3">Location</dt><dd class="col-sm-9"><?php echo e($machine->location); ?></dd>

      <dt class="col-sm-3">Installed At</dt><dd class="col-sm-9"><?php echo e(optional($machine->installed_at)->format('Y-m-d')); ?></dd>

      <dt class="col-sm-3">Status</dt><dd class="col-sm-9"><?php echo e($machine->status); ?></dd>

      <dt class="col-sm-3">Created</dt><dd class="col-sm-9"><?php echo e(optional($machine->created_at)->toDayDateTimeString()); ?></dd>

      <dt class="col-sm-3">Updated</dt><dd class="col-sm-9"><?php echo e(optional($machine->updated_at)->toDayDateTimeString()); ?></dd>

    </dl>

  </div>

</div>

</div>



<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php /**PATH /home2/predictormt/public_html/UAT/resources/views/admin/machines/show.blade.php ENDPATH**/ ?>