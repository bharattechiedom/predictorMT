window.onload = function () {
  // Chart 1 - SplineArea
  var chart1 = new CanvasJS.Chart("chartContainer2", {
    animationEnabled: true,
    title: {
      text: "Registered Users",
    },
    axisY: {
      includeZero: false,
    },
    data: [
      {
        type: "splineArea",
        name: "Buyers",
        showInLegend: true,
        dataPoints: [
          {
            x: new Date(2025, 0),
            y: 30000,
          },
          {
            x: new Date(2025, 1),
            y: 35000,
          },
          {
            x: new Date(2025, 2),
            y: 30000,
          },
          {
            x: new Date(2025, 3),
            y: 30400,
          },
        ],
      },
      {
        type: "splineArea",
        name: "Sellers",
        showInLegend: true,
        dataPoints: [
          {
            x: new Date(2025, 0),
            y: 20100,
          },
          {
            x: new Date(2025, 1),
            y: 16000,
          },
          {
            x: new Date(2025, 2),
            y: 14000,
          },
          {
            x: new Date(2025, 3),
            y: 18000,
          },
        ],
      },
    ],
  });
  chart1.render();

  // Chart 2 - Bar Chart
  var chart2 = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
    title: {
      text: "Monthly Stats",
    },
    axisY: {
      title: "Users",
    },
    data: [
      {
        type: "column",
        dataPoints: [
          {
            label: "Jan",
            y: 297571,
            color: "#f5a623",
          },
          {
            label: "Feb",
            y: 267017,
            color: "#f76b1c",
          },
          {
            label: "Mar",
            y: 175200,
            color: "#d94a8c",
          },
          {
            label: "Apr",
            y: 154580,
            color: "#8e44ad",
          },
        ],
      },
    ],
  });
  chart2.render();
};
