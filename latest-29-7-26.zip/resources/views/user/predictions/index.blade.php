<?php

$page_title = "Failure Insights";

?>



@include('user.include.header')



<body>

  <div class="wrapper active">

    <div class="page-content">

      <div class="page-container p-3 bg-white rounded shadow-sm">

        <div class="row">



          <!-- Header -->

          <div class="card-header d-flex flex-wrap align-items-center gap-2 mb-3">

            <div class="flex-grow-1">

              <h4 class="header-title mb-0">Failure Timeline, Recommendations, ML Explanation</h4>

              <nav aria-label="breadcrumb" class="mt-2">

                <ol class="breadcrumb p-0">

                  <li class="breadcrumb-item">

                    <a href="/analysis/index.php">Dashboard</a>

                  </li>

                  <li class="breadcrumb-item active" aria-current="page">Failure Insights</li>

                </ol>

              </nav>

            </div>

          </div>



          <!-- Filters Row -->

          <div class="container-fluid mt-3 mb-4">

            <div class="row align-items-center">

              <div class="col-lg-8 col-md-12">

                <div class="row g-3">

                  <div class="col-lg-3 col-md-6">

                    <input type="text" class="form-control" placeholder="Failure ID">

                  </div>

                  <div class="col-lg-3 col-md-6">

                    <input type="date" class="form-control">

                  </div>

                  <div class="col-lg-3 col-md-6">

                    <select class="form-select">

                      <option selected="">Facility</option>

                      <option>Plant A</option>

                      <option>Plant B</option>

                      <option>Plant C</option>

                    </select>

                  </div>

                </div>

              </div>



              <!-- Right Buttons -->

             

            </div>

          </div>



          <!-- Main Cards Section -->

          <div class="col-md-12">



            <!-- 1. Failure Timeline -->

            <div class="card mb-3">

              <div class="card-header bg-light">

                <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Failure Timeline</h5>

              </div>

              <div class="card-body">

                <p class="text-white mb-2">Chronological sequence of events leading to failure:</p>

                <ul class="list-unstyled mb-0 text-white">

                  <li><strong>12 Sep 2025:</strong><span class="text-white"> Temperature fluctuations detected </span></li>

                  <li><strong>14 Sep 2025:</strong> <span class="text-white"> Battery performance dropped below threshold </span></li>

                  <li><strong>18 Sep 2025:</strong> <span class="text-white"> Signal interruptions observed </span></li>

                  <li><strong>20 Sep 2025:</strong> <span class="text-white">Device shutdown and failure recorded </span></li>

                </ul>

              </div>

            </div>



            <!-- 2. Recommendations -->

            <div class="card mb-3">

              <div class="card-header bg-light">

                <h5 class="mb-0"><i class="bi bi-lightbulb me-2"></i>Recommendations</h5>

              </div>

              <div class="card-body">

                <ul class="list-unstyled mb-0 text-white">

                  <li class="text-white">✔ Replace batteries in Sensor Cluster B immediately.</li>

                  <li class="text-white">✔ Schedule preventive maintenance in Facility B within 48 hours.</li>

                  <li class="text-white">✔ Update firmware version to latest release (v2.4.1).</li>

                  <li class="text-white">✔ Monitor data transmission intervals every 6 hours.</li>

                </ul>

              </div>

            </div>



            <!-- 3. ML Explanation -->

            <div class="card mb-3">

              <div class="card-header bg-light">

                <h5 class="mb-0"><i class="bi bi-cpu me-2"></i>ML Explanation</h5>

              </div>

              <div class="card-body">

                <p class="text-white ">

                  Machine Learning Model <strong>“FailurePredict-v3”</strong> identified a <strong>92% probability</strong> 

                  of failure based on:

                </p>

                <ul class="list-unstyled text-white">

                  <li>• <strong>Sensor Drift:</strong> <span class="text-white"> 45% influence </span></li>

                  <li>• <strong>Temperature Variation:</strong> <span class="text-white"> 30% influence </span></li>

                  <li>• <strong>Battery Health:</strong> <span class="text-white"> 15% influence </span></li>

                  <li>• <strong>Firmware Latency:</strong> <span class="text-white"> 10% influence </span></li>

                </ul>

              

              </div>

            </div>



          </div> <!-- /col-md-12 -->



        </div> <!-- /row -->

      </div> <!-- /page-container -->

    </div> <!-- /page-content -->

  </div> <!-- /wrapper -->



 

</body>

@include('user.include.footer')

