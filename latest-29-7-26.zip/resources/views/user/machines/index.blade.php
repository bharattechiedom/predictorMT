<?php

$page_title = "List View";

?>

 @include('user.include.header')



<div class="page-content p-3 bg-white">

 <div class="card-header d-flex justify-content-between align-items-center mb-3">

  <h4 class="header-title mb-0">Machines</h4>

  <div class="d-flex gap-2">

    <div class="search-box position-relative w-auto">

      <input type="text" class="form-control pe-5" id="machineSearch" placeholder="Search Machines...">

      <span class="position-absolute top-50 end-0 translate-middle-y pe-3" style="color: #ccc;">

        <i class="bi bi-search"></i>

      </span>

    </div>

    <a href="{{ route('user.machines.create') }}" class="btn btn-dark">Add</a>

  </div>

</div>



  <div class="table-responsive">

    <table class="table table-hover table-bordered">

      <thead class="bg-light">

        <tr>

          <th>#</th>

          <th>Name</th>

          <th>Type</th>

          <th>Serial</th>

          <th>Location</th>

          <th>Status</th>

          <th class="text-center" width="100">Action</th>

        </tr>

      </thead>

      <tbody>

        @forelse($machines as $machine)

        <tr>

          <td>{{ $loop->iteration + ($machines->currentPage()-1)*$machines->perPage() }}</td>

          <td>{{ $machine->name }}</td>

          <td>{{ $machine->machine_type }}</td>

          <td>{{ $machine->serial_number }}</td>

          <td>{{ $machine->location }}</td>

          <td><span class="badge bg-success">{{ $machine->status ?: 'N/A' }}</span></td>

          <td>

            <div class="d-flex gap-2 table-td-Btn">

              <a href="{{ route('user.machines.edit', $machine) }}" class="btn btn-sm btn-outline-info" title="Edit">

                <i class="bi bi-pencil"></i>

              </a>

              <a href="{{ route('user.machines.show', $machine) }}" class="btn btn-sm btn-outline-info" title="View">

                <i class="bi bi-eye"></i>

              </a>

              <form method="POST" action="{{ route('user.machines.destroy', $machine) }}" onsubmit="return confirm('Delete this machine?');">

                @csrf

                @method('DELETE')

                <button type="submit" class="btn btn-sm btn-outline-info" title="Delete">

                  <i class="bi bi-trash"></i>

                </button>

              </form>

            </div>

          </td>

        </tr>

        @empty

        <tr>

          <td colspan="7" class="text-center">No machines found.</td>

        </tr>

        @endforelse

      </tbody>

    </table>

  </div>



  <div class="mt-3">

    {{ $machines->links() }}

  </div>

</div>



<script>

(function() {

    'use strict';

    

    const searchInput = document.getElementById('machineSearch');

    const table = document.querySelector('.table tbody');

    

    if (searchInput && table) {

        searchInput.addEventListener('input', function() {

            const searchTerm = this.value.toLowerCase().trim();

            const rows = table.querySelectorAll('tr');

            

            rows.forEach(function(row) {

                if (row.querySelector('td[colspan]')) {

                    return;

                }

                

                const text = row.textContent.toLowerCase();

                row.style.display = text.includes(searchTerm) ? '' : 'none';

            });

        });

    }

})();

</script>



@include('user.include.footer')