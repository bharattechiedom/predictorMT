<?php $page_title = "predictorMt - home";

 ?>

 @include('user.include.header')



<!-- ============================================================== -->

<!-- Start Page Content here -->

<div class="page-content dashboard-page">



    <div class="page-title-head d-flex align-items-center gap-2 bg-white p-3 m-0">

        <div class="flex-grow-1">

            <h4 class="headings">KPIs, Live Data & Predictions Summary</h4>

        </div>

    </div>



    <div class="page-container p-0">

        <div class="container-fluid px-3">



            <div class="row cardBox">

                <!-- Left Half: 2x2 Stat Cards -->

                <div class="col-lg-12 col-md-12">

                    <div class="row g-3">



                        <!-- System Uptime -->

                        <div class="col-lg-3 col-md-12">

                            <div class="card  h-100 text-center">

                                <div class="card-body">

                                    <p class="card-text mb-0 text-left" style="font-size:15px !important;text-align:left">

                                        System Uptime

                                    </p>

                                    <h5 class="card-title mb-1" style="text-align:left">99.8%</h5>

                                    <div class="icon-box display-4">

                                        <i class="bi bi-speedometer2"></i>

                                    </div>

                                </div>

                            </div>

                        </div>



                        <!-- Real-Time Active Users -->

                        <div class="col-lg-3 col-md-12">

                            <div class="card h-100 text-center">

                                <div class="card-body">

                                    <p class="card-text mb-0 text-left" style="font-size:15px !important;text-align:left">

                                        Real-Time Active Users

                                    </p>

                                    <h5 class="card-title mb-1" style="text-align:left">125</h5>

                                    <div class="icon-box display-4">

                                        <i class="bi bi-people-fill"></i>

                                    </div>

                                </div>

                            </div>

                        </div>



                        <!-- AI Predictions Generated -->

                        <div class="col-lg-3 col-md-12">

                            <div class="card h-100 text-center">

                                <div class="card-body">

                                    <p class="card-text mb-0 text-left" style="font-size:15px !important;text-align:left">

                                        AI Predictions Generated

                                    </p>

                                    <h5 class="card-title mb-1" style="text-align:left">842</h5>

                                    <div class="icon-box display-4">

                                        <i class="bi bi-cpu-fill"></i>

                                    </div>

                                </div>

                            </div>

                        </div>



                        <!-- Data Accuracy -->

                        <div class="col-lg-3 col-md-12">

                            <div class="card h-100 text-center">

                                <div class="card-body">

                                    <p class="card-text mb-0 text-left" style="font-size:15px !important;text-align:left">

                                        Data Accuracy

                                    </p>

                                    <h5 class="card-title mb-1" style="text-align:left">97.4%</h5>

                                    <div class="icon-box display-4">

                                        <i class="bi bi-graph-up-arrow"></i>

                                    </div>

                                </div>

                            </div>

                        </div>



                    </div>

                </div>

            </div>



            <!-- Payments & Subscriptions Section -->

            <div class="row mt-4">

                <div class="col-lg-8">

                    <div class="card bg-white">

                        <div class="card-body">

                            <h5 class="card-title theme-heading-color">Recent Payments</h5>

                            <div class="table-responsive">

                                    <table class="table table-hover table-bordered">

                                        <thead class="bg-light">

                                            <tr>

                                                <th>Date</th>

                                                <th>Plan</th>

                                                <th>Amount</th>

                                                <th>Currency</th>

                                                <th>Status</th>

                                                <th>Session</th>

                                            </tr>

                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td>-</td>
                                            </tr>
                                        </tbody>
</table>
</div>

                            @if(!empty($payments) && $payments->count())

                                <div class="table-responsive">

                                    <table class="table table-sm">

                                        <thead>

                                            <tr>

                                                <th>Date</th>

                                                <th>Plan</th>

                                                <th>Amount</th>

                                                <th>Currency</th>

                                                <th>Status</th>

                                                <th>Session</th>

                                            </tr>

                                        </thead>

                                        <tbody>

                                            @foreach($payments as $p)

                                                <tr>

                                                    <td>{{ $p->created_at ? $p->created_at->format('Y-m-d H:i') : '' }}</td>

                                                    <td>{{ $p->plan ? $p->plan->name : ($p->plan_id ? 'Plan #' . $p->plan_id : '-') }}</td>

                                                    <td>{{ $p->amount !== null ? number_format($p->amount,2) : '-' }}</td>

                                                    <td>{{ strtoupper($p->currency ?? config('app.currency','CAD')) }}</td>

                                                    <td>{{ ucfirst($p->status ?? '-') }}</td>

                                                    <td style="max-width:180px; word-break:break-all">{{ $p->stripe_session_id }}</td>

                                                </tr>

                                            @endforeach

                                        </tbody>

                                    </table>

                                </div>

                            @else

                                <p class="text-muted">No payments found for your account.</p>

                            @endif

                        </div>

                    </div>

                </div>



                <div class="col-lg-4">

                    <div class="card">

                        <div class="card-body">

                            <h5 class="card-title text-white">Subscriptions</h5>

                            @if(!empty($subscriptions) && $subscriptions->count())

                                <ul class="list-group list-group-flush">

                                    @foreach($subscriptions as $s)

                                        <li class="list-group-item">

                                            <strong>{{ $s->plan ? $s->plan->name : ('Plan #' . $s->plan_id) }}</strong>

                                            <div class="small text-muted">Status: {{ ucfirst($s->status) }}</div>

                                            <div class="small text-muted">Started: {{ $s->started_at ? $s->started_at->format('Y-m-d') : '-' }}</div>

                                            <div class="small text-muted">Ends: {{ $s->ended_at ? $s->ended_at->format('Y-m-d') : 'N/A' }}</div>

                                        </li>

                                    @endforeach

                                </ul>

                            @else

                                <p class="text-white">No active subscriptions for your company.</p>

                            @endif

                        </div>

                    </div>

                </div>

            </div>



        </div>

    </div>



</div>



<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>



@include('user.include.footer')

